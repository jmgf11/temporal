# 🤖 Agente Autónomo

Un agente de IA autónomo con capacidades completas de control del sistema, navegación web, manipulación de archivos y ejecución de código.

## ✨ Características

- 🖥️ **Control del Sistema**: Ejecuta comandos bash y controla el sistema operativo
- 🌐 **Navegación Web**: Navega sitios web, toma screenshots, extrae información
- 📁 **Gestión de Archivos**: Lee, escribe, lista y busca archivos
- 🐍 **Ejecución de Python**: Ejecuta código Python dinámicamente
- 💬 **Múltiples Interfaces**: CLI interactivo y bot de Telegram
- 🧠 **Memoria de Conversación**: Mantiene contexto entre mensajes
- 🔧 **Extensible**: Fácil agregar nuevas herramientas y capacidades

## 📋 Requisitos

- Ubuntu 22.04+ (o cualquier distribución Linux compatible)
- Python 3.10+
- 4GB RAM mínimo (8GB recomendado para Ollama)

### Opciones de IA:

**Opción 1: Claude/OpenAI (DE PAGO)**
- Clave de API de Anthropic o OpenAI
- $5 gratis al registrarte en Anthropic
- Mejor calidad, más rápido
- ~$1-5 USD por día de uso moderado

**Opción 2: Ollama (100% GRATIS)** ⭐ RECOMENDADO PARA EMPEZAR
- Sin API keys necesarias
- Modelos corren localmente en tu VM
- Totalmente gratis, sin límites
- 8-16GB RAM recomendado
- Ver guía completa: [OLLAMA_GUIDE.md](OLLAMA_GUIDE.md)

**Opción 3: Híbrido (MEJOR DE AMBOS)** 🎯
- Usa Claude mientras tengas crédito gratis
- Cambia automáticamente a Ollama cuando se acabe
- ¡Lo mejor de ambos mundos!

## 🚀 Instalación Rápida

### Opción 1: Script Automático

```bash
cd agente-autonomo
chmod +x install.sh
./install.sh
```

### Opción 2: Manual

```bash
# 1. Instalar dependencias del sistema
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3 python3-pip python3-venv git chromium-browser

# 2. Crear entorno virtual
python3 -m venv venv
source venv/bin/activate

# 3. Instalar dependencias Python
pip install -r requirements.txt

# 4. Instalar navegadores para Playwright
playwright install chromium
playwright install-deps

# 5. Configurar variables de entorno
cp .env.example .env
nano .env  # Editar y agregar tus API keys
```

## ⚙️ Configuración

### Opción A: Usar Ollama (100% Gratis) ⭐

```bash
# 1. Instalar Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# 2. Descargar modelo (recomendado para 8GB RAM)
ollama pull llama3.1

# 3. Iniciar servidor
ollama serve &

# 4. Configurar .env (dejar API keys vacías)
cp .env.example .env
nano .env
# No necesitas configurar ANTHROPIC_API_KEY
# Solo asegúrate que tenga: OLLAMA_MODEL=llama3.1

# ¡Listo! El agente usará Ollama automáticamente
```

Ver guía completa: [OLLAMA_GUIDE.md](OLLAMA_GUIDE.md)

### Opción B: Usar Claude (De Pago, $5 Gratis)

### Obtener API Keys

1. **Anthropic API Key** (Requerido)
   - Ve a https://console.anthropic.com/
   - Crea una cuenta o inicia sesión
   - Ve a "API Keys" y crea una nueva
   - Copia la clave

2. **Telegram Bot Token** (Opcional, solo para bot de Telegram)
   - Habla con [@BotFather](https://t.me/BotFather) en Telegram
   - Usa `/newbot` y sigue las instrucciones
   - Copia el token que te proporciona

### Editar .env

```bash
nano .env
```

Agrega tus claves:

```env
ANTHROPIC_API_KEY=sk-ant-api03-...
TELEGRAM_BOT_TOKEN=123456789:ABC...  # Solo si usarás Telegram
```

## 🎯 Uso

### Modo CLI (Línea de Comandos)

```bash
source venv/bin/activate
python main.py cli
```

Comandos especiales en CLI:
- `/help` - Muestra ayuda
- `/reset` - Reinicia la conversación
- `/status` - Muestra estado del agente
- `/exit` - Salir

### Modo Telegram

```bash
source venv/bin/activate
python main.py telegram
```

Luego busca tu bot en Telegram y envía `/start`

### Modo de Prueba

```bash
python main.py test
```

## 💡 Ejemplos de Uso

### Archivos y Directorios
```
Tú: Lista los archivos en el directorio actual
Tú: Crea un archivo llamado notas.txt con el contenido "Hola mundo"
Tú: Lee el contenido del archivo /etc/os-release
```

### Comandos del Sistema
```
Tú: Ejecuta 'df -h' para ver el espacio en disco
Tú: Muéstrame los procesos que más consumen CPU
Tú: Instala el paquete htop
```

### Navegación Web
```
Tú: Busca información sobre Python en Wikipedia
Tú: Toma un screenshot de google.com
Tú: Extrae los títulos de https://news.ycombinator.com
```

### Programación
```
Tú: Ejecuta un script Python que calcule los primeros 20 números de Fibonacci
Tú: Calcula la media y desviación estándar de estos números: 10, 20, 30, 40, 50
```

### Tareas Complejas
```
Tú: Busca las últimas noticias sobre IA, guárdalas en un archivo y dame un resumen
Tú: Descarga la página de Python.org, extrae todos los enlaces y guárdalos en links.txt
```

## 📁 Estructura del Proyecto

```
agente-autonomo/
├── main.py                 # Punto de entrada
├── requirements.txt        # Dependencias Python
├── install.sh             # Script de instalación
├── .env.example           # Plantilla de configuración
├── .env                   # Tu configuración (no commitear)
│
├── core/
│   ├── agent.py          # Lógica principal del agente
│   └── memory.py         # Sistema de memoria (futuro)
│
├── interfaces/
│   ├── cli.py            # Interfaz de línea de comandos
│   └── telegram_bot.py   # Bot de Telegram
│
├── skills/
│   └── (habilidades personalizadas)
│
└── data/
    ├── agent.log         # Logs del agente
    └── memory.db         # Base de datos (futuro)
```

## 🔒 Seguridad

### Configuración Recomendada

El agente tiene acceso completo al sistema, por lo que:

1. **Ejecutar en VM**: Usa una máquina virtual aislada
2. **Limitar comandos**: Edita `ALLOW_BASH` en .env
3. **Revisar logs**: Monitorea `data/agent.log`
4. **No exponer**: No hagas público tu bot sin autenticación

### Variables de Seguridad en .env

```env
ALLOW_BASH=true          # Permitir comandos bash
SANDBOX_MODE=false       # Modo sandbox (limita acceso)
MAX_COMMAND_LENGTH=500   # Longitud máxima de comandos
```

## 🐛 Solución de Problemas

### Error: "ANTHROPIC_API_KEY no configurada"
```bash
# Verifica que .env existe y tiene la clave
cat .env | grep ANTHROPIC_API_KEY
```

### Error: "playwright install failed"
```bash
# Instalar dependencias manualmente
sudo apt install -y libnss3 libatk-bridge2.0-0 libdrm2 libxkbcommon0 libgbm1
playwright install chromium
```

### Error: "ModuleNotFoundError"
```bash
# Asegúrate de activar el entorno virtual
source venv/bin/activate
pip install -r requirements.txt
```

### Bot de Telegram no responde
1. Verifica que el token sea correcto
2. Asegúrate de haber enviado `/start` al bot
3. Revisa los logs: `tail -f data/telegram_bot.log`

## 🚀 Próximas Características

- [ ] Memoria persistente con base de datos
- [ ] Skills personalizados modulares
- [ ] Integración con Discord
- [ ] Soporte para visión por computadora
- [ ] Ejecución de tareas programadas (cron)
- [ ] API REST para integración externa
- [ ] Dashboard web
- [ ] Soporte para múltiples modelos de IA

## 🤝 Contribuir

¡Las contribuciones son bienvenidas! Para contribuir:

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la licencia MIT. Ver `LICENSE` para más detalles.

## 🙏 Agradecimientos

- [Anthropic](https://anthropic.com) por Claude
- [OpenClaw](https://openclaw.ai) por la inspiración
- Comunidad de código abierto

## 📞 Soporte

Si tienes problemas:
1. Revisa la sección de Solución de Problemas
2. Busca en los Issues existentes
3. Crea un nuevo Issue con detalles del problema

## ⚠️ Advertencia

Este agente tiene acceso completo al sistema donde se ejecuta. Úsalo de manera responsable:
- Ejecuta en una VM o entorno aislado
- No le des credenciales sensibles
- Revisa los comandos antes de ejecutarlos
- Monitorea los logs regularmente

---

**Hecho con ❤️ por la comunidad**
