"""
Sistema de Proveedores de LLM
Soporta múltiples proveedores con fallback automático
"""

import os
import logging
from typing import List, Dict, Any, Optional
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)


class LLMProvider(ABC):
    """Clase base para proveedores de LLM"""
    
    @abstractmethod
    def generate(
        self, 
        messages: List[Dict],
        tools: List[Dict] = None,
        max_tokens: int = 4096
    ) -> Dict:
        """Genera una respuesta del modelo"""
        pass
    
    @abstractmethod
    def is_available(self) -> bool:
        """Verifica si el proveedor está disponible"""
        pass
    
    @abstractmethod
    def get_name(self) -> str:
        """Retorna el nombre del proveedor"""
        pass


class AnthropicProvider(LLMProvider):
    """Proveedor para Claude (Anthropic)"""
    
    def __init__(self, api_key: str = None, model: str = None):
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        self.model = model or os.getenv("DEFAULT_MODEL", "claude-sonnet-4-20250514")
        self.client = None
        
        if self.api_key:
            try:
                from anthropic import Anthropic
                self.client = Anthropic(api_key=self.api_key)
                logger.info(f"AnthropicProvider inicializado con modelo {self.model}")
            except Exception as e:
                logger.error(f"Error inicializando Anthropic: {e}")
    
    def is_available(self) -> bool:
        return self.client is not None and self.api_key is not None
    
    def get_name(self) -> str:
        return f"Anthropic Claude ({self.model})"
    
    def generate(
        self, 
        messages: List[Dict],
        tools: List[Dict] = None,
        max_tokens: int = 4096
    ) -> Dict:
        """Genera respuesta usando Claude"""
        try:
            kwargs = {
                "model": self.model,
                "max_tokens": max_tokens,
                "messages": messages
            }
            
            if tools:
                kwargs["tools"] = tools
            
            response = self.client.messages.create(**kwargs)
            
            return {
                "content": response.content,
                "stop_reason": response.stop_reason,
                "provider": "anthropic",
                "model": self.model
            }
            
        except Exception as e:
            logger.error(f"Error en AnthropicProvider: {e}")
            raise


class OllamaProvider(LLMProvider):
    """Proveedor para Ollama (local, gratis)"""
    
    def __init__(self, model: str = None, base_url: str = None):
        self.model = model or os.getenv("OLLAMA_MODEL", "llama3.1")
        self.base_url = base_url or os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        self.available = self._check_availability()
        
        if self.available:
            logger.info(f"OllamaProvider inicializado con modelo {self.model}")
        else:
            logger.warning("Ollama no está disponible")
    
    def _check_availability(self) -> bool:
        """Verifica si Ollama está corriendo"""
        try:
            import requests
            response = requests.get(f"{self.base_url}/api/tags", timeout=2)
            return response.status_code == 200
        except:
            return False
    
    def is_available(self) -> bool:
        return self.available
    
    def get_name(self) -> str:
        return f"Ollama ({self.model}) - GRATIS"
    
    def generate(
        self, 
        messages: List[Dict],
        tools: List[Dict] = None,
        max_tokens: int = 4096
    ) -> Dict:
        """Genera respuesta usando Ollama"""
        import requests
        import json
        
        try:
            # Convertir mensajes al formato de Ollama
            prompt = self._messages_to_prompt(messages)
            
            # Si hay herramientas, agregarlas al prompt
            if tools:
                tools_desc = self._format_tools(tools)
                prompt = f"{tools_desc}\n\n{prompt}"
            
            # Llamar a Ollama
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "num_predict": max_tokens
                    }
                },
                timeout=120
            )
            
            result = response.json()
            
            # Parsear respuesta para detectar tool use
            response_text = result.get("response", "")
            content, stop_reason = self._parse_response(response_text, tools)
            
            return {
                "content": content,
                "stop_reason": stop_reason,
                "provider": "ollama",
                "model": self.model
            }
            
        except Exception as e:
            logger.error(f"Error en OllamaProvider: {e}")
            raise
    
    def _messages_to_prompt(self, messages: List[Dict]) -> str:
        """Convierte mensajes de Claude a prompt de Ollama"""
        prompt_parts = []
        
        for msg in messages:
            role = msg["role"]
            content = msg["content"]
            
            if isinstance(content, str):
                if role == "user":
                    prompt_parts.append(f"Usuario: {content}")
                elif role == "assistant":
                    prompt_parts.append(f"Asistente: {content}")
            elif isinstance(content, list):
                # Manejar contenido complejo (tool results, etc)
                text_parts = []
                for item in content:
                    if isinstance(item, dict):
                        if item.get("type") == "text":
                            text_parts.append(item.get("text", ""))
                        elif item.get("type") == "tool_result":
                            text_parts.append(f"Resultado: {item.get('content', '')}")
                
                combined = " ".join(text_parts)
                if role == "user":
                    prompt_parts.append(f"Usuario: {combined}")
                else:
                    prompt_parts.append(f"Asistente: {combined}")
        
        return "\n\n".join(prompt_parts)
    
    def _format_tools(self, tools: List[Dict]) -> str:
        """Formatea herramientas para el prompt"""
        tools_text = "Tienes acceso a las siguientes herramientas:\n\n"
        
        for tool in tools:
            name = tool.get("name", "")
            desc = tool.get("description", "")
            tools_text += f"- {name}: {desc}\n"
        
        tools_text += "\nPara usar una herramienta, responde en formato JSON:\n"
        tools_text += '{"tool": "nombre_herramienta", "input": {...}}\n\n'
        
        return tools_text
    
    def _parse_response(self, response_text: str, tools: List[Dict]) -> tuple:
        """Parsea la respuesta para detectar uso de herramientas"""
        import json
        import re
        
        # Buscar JSON en la respuesta
        json_match = re.search(r'\{[^}]*"tool"[^}]*\}', response_text)
        
        if json_match and tools:
            try:
                tool_call = json.loads(json_match.group())
                
                # Crear estructura compatible con Claude
                content = [{
                    "type": "tool_use",
                    "id": f"tool_{hash(response_text)}",
                    "name": tool_call.get("tool"),
                    "input": tool_call.get("input", {})
                }]
                
                # Agregar texto antes del JSON si existe
                text_before = response_text[:json_match.start()].strip()
                if text_before:
                    content.insert(0, {
                        "type": "text",
                        "text": text_before
                    })
                
                return content, "tool_use"
                
            except json.JSONDecodeError:
                pass
        
        # Si no hay tool use, retornar como texto
        return [{"type": "text", "text": response_text}], "end_turn"


class OpenAIProvider(LLMProvider):
    """Proveedor para OpenAI (GPT)"""
    
    def __init__(self, api_key: str = None, model: str = None):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.model = model or os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        self.client = None
        
        if self.api_key:
            try:
                from openai import OpenAI
                self.client = OpenAI(api_key=self.api_key)
                logger.info(f"OpenAIProvider inicializado con modelo {self.model}")
            except Exception as e:
                logger.error(f"Error inicializando OpenAI: {e}")
    
    def is_available(self) -> bool:
        return self.client is not None and self.api_key is not None
    
    def get_name(self) -> str:
        return f"OpenAI ({self.model})"
    
    def generate(
        self, 
        messages: List[Dict],
        tools: List[Dict] = None,
        max_tokens: int = 4096
    ) -> Dict:
        """Genera respuesta usando OpenAI"""
        try:
            # Convertir mensajes de Claude a formato OpenAI
            openai_messages = self._convert_messages(messages)
            
            kwargs = {
                "model": self.model,
                "messages": openai_messages,
                "max_tokens": max_tokens
            }
            
            if tools:
                kwargs["tools"] = self._convert_tools(tools)
            
            response = self.client.chat.completions.create(**kwargs)
            
            # Convertir respuesta a formato Claude
            message = response.choices[0].message
            content = self._convert_response(message)
            
            stop_reason = "tool_use" if message.tool_calls else "end_turn"
            
            return {
                "content": content,
                "stop_reason": stop_reason,
                "provider": "openai",
                "model": self.model
            }
            
        except Exception as e:
            logger.error(f"Error en OpenAIProvider: {e}")
            raise
    
    def _convert_messages(self, messages: List[Dict]) -> List[Dict]:
        """Convierte mensajes de Claude a OpenAI"""
        # Simplificación - en producción necesitarías conversión más robusta
        return messages
    
    def _convert_tools(self, tools: List[Dict]) -> List[Dict]:
        """Convierte herramientas de Claude a OpenAI"""
        # Simplificación
        return tools
    
    def _convert_response(self, message) -> List[Dict]:
        """Convierte respuesta de OpenAI a formato Claude"""
        content = []
        
        if message.content:
            content.append({"type": "text", "text": message.content})
        
        if message.tool_calls:
            for tool_call in message.tool_calls:
                content.append({
                    "type": "tool_use",
                    "id": tool_call.id,
                    "name": tool_call.function.name,
                    "input": eval(tool_call.function.arguments)
                })
        
        return content


class LLMManager:
    """Gestor de proveedores con fallback automático"""
    
    def __init__(self):
        self.providers: List[LLMProvider] = []
        self.current_provider: Optional[LLMProvider] = None
        self._initialize_providers()
    
    def _initialize_providers(self):
        """Inicializa proveedores en orden de prioridad"""
        
        # 1. Anthropic (Claude) - Mejor calidad, de pago
        anthropic = AnthropicProvider()
        if anthropic.is_available():
            self.providers.append(anthropic)
            logger.info("✓ Anthropic disponible")
        
        # 2. OpenAI - Alternativa de pago
        openai = OpenAIProvider()
        if openai.is_available():
            self.providers.append(openai)
            logger.info("✓ OpenAI disponible")
        
        # 3. Ollama - Local, gratis (fallback)
        ollama = OllamaProvider()
        if ollama.is_available():
            self.providers.append(ollama)
            logger.info("✓ Ollama disponible (GRATIS)")
        
        if not self.providers:
            raise RuntimeError(
                "No hay proveedores de LLM disponibles. "
                "Configura ANTHROPIC_API_KEY o instala Ollama."
            )
        
        # Usar el primer proveedor disponible
        self.current_provider = self.providers[0]
        logger.info(f"Proveedor activo: {self.current_provider.get_name()}")
    
    def generate(
        self,
        messages: List[Dict],
        tools: List[Dict] = None,
        max_tokens: int = 4096
    ) -> Dict:
        """
        Genera respuesta usando el proveedor actual
        Si falla, intenta con el siguiente proveedor (fallback)
        """
        
        for i, provider in enumerate(self.providers):
            try:
                logger.debug(f"Intentando con {provider.get_name()}")
                
                if not provider.is_available():
                    continue
                
                response = provider.generate(messages, tools, max_tokens)
                
                # Si el proveedor cambió, notificar
                if provider != self.current_provider:
                    old_provider = self.current_provider.get_name()
                    new_provider = provider.get_name()
                    logger.warning(
                        f"Cambiado de {old_provider} a {new_provider}"
                    )
                    self.current_provider = provider
                
                return response
                
            except Exception as e:
                logger.error(f"Error con {provider.get_name()}: {e}")
                
                # Si es el último proveedor, lanzar error
                if i == len(self.providers) - 1:
                    raise
                
                # Intentar con el siguiente proveedor
                logger.info(f"Intentando con siguiente proveedor...")
                continue
        
        raise RuntimeError("Todos los proveedores fallaron")
    
    def get_current_provider_name(self) -> str:
        """Retorna el nombre del proveedor actual"""
        return self.current_provider.get_name() if self.current_provider else "Ninguno"
    
    def list_providers(self) -> List[str]:
        """Lista todos los proveedores disponibles"""
        return [p.get_name() for p in self.providers]
