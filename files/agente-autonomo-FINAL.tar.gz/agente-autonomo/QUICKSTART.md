# 🚀 Guía de Inicio Rápido

## Instalación en 5 Minutos

### 1. Preparar Ubuntu VM

```bash
# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Transferir archivos a la VM
# Opción A: Usar scp
scp -r agente-autonomo/ usuario@ip-de-vm:~/

# Opción B: Git clone (si tienes un repo)
git clone tu-repositorio.git
cd agente-autonomo
```

### 2. Ejecutar Instalación Automática

```bash
cd agente-autonomo
chmod +x install.sh
./install.sh
```

El script instalará automáticamente:
- Python y dependencias del sistema
- Entorno virtual de Python
- Todas las librerías necesarias
- Playwright y navegadores
- Creará la estructura de directorios

### 3. Configurar API Keys

```bash
# Editar archivo de configuración
nano .env

# Agregar tu clave de Anthropic:
ANTHROPIC_API_KEY=sk-ant-api03-TU_CLAVE_AQUI

# Guardar: Ctrl+O, Enter, Ctrl+X
```

**¿Dónde obtener la API Key?**
1. Ve a https://console.anthropic.com/
2. Crea una cuenta o inicia sesión
3. Crea una API Key
4. Cópiala (¡solo se muestra una vez!)

### 4. Probar la Instalación

```bash
# Activar entorno virtual
source venv/bin/activate

# Ejecutar prueba
python main.py test
```

Si ves ✅ verde, ¡todo está listo!

### 5. ¡Usar el Agente!

#### Modo CLI (recomendado para empezar)

```bash
python main.py cli
```

Prueba estos comandos:
```
Tú: Hola, ¿qué puedes hacer?
Tú: Lista los archivos en mi directorio home
Tú: Crea un archivo test.txt con contenido "Hola desde el agente"
```

#### Modo Telegram (opcional)

```bash
# 1. Crear bot en Telegram
# Habla con @BotFather en Telegram
# Envía: /newbot
# Sigue las instrucciones
# Copia el token

# 2. Agregar token al .env
nano .env
# Agregar: TELEGRAM_BOT_TOKEN=tu_token_aqui

# 3. Iniciar bot
python main.py telegram

# 4. En Telegram, busca tu bot y envía /start
```

## 📱 Acceso Remoto a la VM

### Opción 1: SSH

```bash
# Desde tu computadora principal
ssh usuario@ip-de-vm

# Ejecutar el agente
cd agente-autonomo
source venv/bin/activate
python main.py cli
```

### Opción 2: VS Code Remote

1. Instala la extensión "Remote - SSH" en VS Code
2. Conecta a tu VM
3. Abre la carpeta del proyecto
4. Usa la terminal integrada

### Opción 3: Telegram (Acceso desde Cualquier Lugar)

Una vez configurado el bot de Telegram, puedes controlarlo desde tu teléfono, tablet o cualquier dispositivo con Telegram.

## 🎯 Casos de Uso Comunes

### Automatización de Tareas

```
Tú: Todos los días a las 9 AM, revisa mi email y dame un resumen
Tú: Monitorea el uso de disco y avísame si supera el 80%
Tú: Haz backup de mi carpeta de documentos cada semana
```

### Desarrollo de Software

```
Tú: Crea un servidor web simple en Python con Flask
Tú: Analiza este código y sugiere mejoras
Tú: Ejecuta los tests y dame un reporte
```

### Investigación Web

```
Tú: Busca las últimas noticias sobre IA y resume los puntos clave
Tú: Compara precios de productos en diferentes sitios
Tú: Monitorea esta página y avísame si cambia
```

### Gestión de Archivos

```
Tú: Organiza mis descargas por tipo de archivo
Tú: Encuentra todos los archivos .log y comprime los más antiguos
Tú: Sincroniza esta carpeta con el servidor
```

## ⚙️ Configuraciones Avanzadas

### Limitar Permisos (Más Seguro)

Edita `.env`:
```env
ALLOW_BASH=false          # Desactiva comandos bash
SANDBOX_MODE=true         # Activa modo sandbox
MAX_COMMAND_LENGTH=200    # Reduce longitud de comandos
```

### Cambiar Modelo de IA

```env
# Más rápido y económico
DEFAULT_MODEL=claude-haiku-4-20250514

# Balance (por defecto)
DEFAULT_MODEL=claude-sonnet-4-20250514

# Más potente (para tareas complejas)
DEFAULT_MODEL=claude-opus-4-20250514
```

### Logs Detallados

Edita `interfaces/cli.py` o `interfaces/telegram_bot.py`:
```python
logging.basicConfig(
    level=logging.DEBUG,  # Cambia INFO a DEBUG
    ...
)
```

## 🔍 Monitoreo

### Ver Logs en Tiempo Real

```bash
# Logs del CLI
tail -f data/agent.log

# Logs del bot de Telegram
tail -f data/telegram_bot.log
```

### Verificar Uso de Recursos

```bash
# En la VM
htop

# Uso de disco
df -h

# Procesos del agente
ps aux | grep python
```

## 🆘 Problemas Comunes

### "No module named 'anthropic'"
```bash
source venv/bin/activate
pip install -r requirements.txt
```

### "Permission denied"
```bash
chmod +x install.sh
chmod +x main.py
```

### El agente es muy lento
1. Aumenta la RAM de la VM (8GB recomendado)
2. Usa modelo Haiku en lugar de Sonnet
3. Limita el número de herramientas

### Bot de Telegram no responde
1. Verifica que el token sea correcto
2. Asegúrate que la VM tenga acceso a internet
3. Revisa los logs: `tail -f data/telegram_bot.log`

## 📚 Próximos Pasos

1. **Personaliza el agente**: Agrega tus propias herramientas en `core/agent.py`
2. **Crea skills**: Desarrolla habilidades específicas en `skills/`
3. **Automatiza**: Configura tareas programadas con cron
4. **Integra**: Conecta con otras APIs y servicios
5. **Comparte**: Contribuye al proyecto con tus mejoras

## 💡 Tips Pro

1. **Usa contexto**: El agente recuerda la conversación, aprovéchalo
2. **Sé específico**: Cuanto más claro, mejores resultados
3. **Iterativo**: Divide tareas grandes en pasos pequeños
4. **Experimenta**: Prueba diferentes formas de pedir lo mismo
5. **Monitorea**: Revisa los logs regularmente

## 🎓 Recursos Adicionales

- [Documentación de Claude](https://docs.anthropic.com)
- [API de Anthropic](https://docs.anthropic.com/en/api)
- [Playwright Docs](https://playwright.dev/python/)
- [Python Telegram Bot](https://python-telegram-bot.org/)

---

¿Dudas? Revisa el README.md completo o abre un issue en GitHub.

**¡Disfruta de tu agente autónomo!** 🤖✨
