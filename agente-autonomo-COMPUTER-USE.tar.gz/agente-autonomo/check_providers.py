#!/usr/bin/env python3
"""
Script para verificar qué proveedores de LLM están disponibles
"""

import os
import sys
from pathlib import Path

# Agregar directorio raíz al path
root_dir = Path(__file__).parent
sys.path.insert(0, str(root_dir))

from dotenv import load_dotenv
load_dotenv()

print("╔═══════════════════════════════════════════════════════╗")
print("║     🔍  VERIFICADOR DE PROVEEDORES DE IA  🔍         ║")
print("╚═══════════════════════════════════════════════════════╝")
print()

# Verificar Anthropic
print("1️⃣  Anthropic (Claude)")
anthropic_key = os.getenv("ANTHROPIC_API_KEY")
if anthropic_key and len(anthropic_key) > 10:
    try:
        from anthropic import Anthropic
        client = Anthropic(api_key=anthropic_key)
        print("   ✅ Disponible")
        print(f"   📝 API Key: {anthropic_key[:10]}...{anthropic_key[-4:]}")
        print(f"   🎯 Modelo: {os.getenv('DEFAULT_MODEL', 'claude-sonnet-4-20250514')}")
    except Exception as e:
        print(f"   ⚠️  Configurada pero con error: {e}")
else:
    print("   ❌ No configurada")
    print("   💡 Obtén tu clave en: https://console.anthropic.com/")

print()

# Verificar OpenAI
print("2️⃣  OpenAI (GPT)")
openai_key = os.getenv("OPENAI_API_KEY")
if openai_key and len(openai_key) > 10:
    try:
        from openai import OpenAI
        client = OpenAI(api_key=openai_key)
        print("   ✅ Disponible")
        print(f"   📝 API Key: {openai_key[:10]}...{openai_key[-4:]}")
        print(f"   🎯 Modelo: {os.getenv('OPENAI_MODEL', 'gpt-4o-mini')}")
    except Exception as e:
        print(f"   ⚠️  Configurada pero con error: {e}")
else:
    print("   ❌ No configurada")
    print("   💡 Obtén tu clave en: https://platform.openai.com/")

print()

# Verificar Ollama
print("3️⃣  Ollama (Local - GRATIS)")
try:
    import requests
    base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    response = requests.get(f"{base_url}/api/tags", timeout=2)
    
    if response.status_code == 200:
        models = response.json().get("models", [])
        print("   ✅ Disponible y corriendo")
        print(f"   🌐 URL: {base_url}")
        print(f"   🎯 Modelo: {os.getenv('OLLAMA_MODEL', 'llama3.1')}")
        print(f"   📚 Modelos instalados: {len(models)}")
        
        if models:
            print("   📋 Modelos:")
            for model in models[:5]:  # Mostrar primeros 5
                name = model.get("name", "unknown")
                size = model.get("size", 0) / 1e9  # Convertir a GB
                print(f"      • {name} ({size:.1f}GB)")
    else:
        print("   ⚠️  Servidor respondió con error")
        
except requests.exceptions.ConnectionError:
    print("   ❌ No está corriendo")
    print("   💡 Iniciar con: ollama serve &")
    print("   💡 Instalar: curl -fsSL https://ollama.ai/install.sh | sh")
except Exception as e:
    print(f"   ❌ Error: {e}")

print()
print("═" * 55)

# Resumen
available = []
if anthropic_key and len(anthropic_key) > 10:
    available.append("Anthropic")
if openai_key and len(openai_key) > 10:
    available.append("OpenAI")

try:
    import requests
    base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    response = requests.get(f"{base_url}/api/tags", timeout=2)
    if response.status_code == 200:
        available.append("Ollama (GRATIS)")
except:
    pass

if available:
    print(f"✅ Proveedores disponibles: {', '.join(available)}")
    print()
    print("🚀 Puedes iniciar el agente con:")
    print("   python main.py cli")
else:
    print("❌ No hay proveedores disponibles")
    print()
    print("Opciones:")
    print("1. 🆓 Instalar Ollama (GRATIS):")
    print("   curl -fsSL https://ollama.ai/install.sh | sh")
    print("   ollama pull llama3.1")
    print("   ollama serve &")
    print()
    print("2. 💳 Configurar Claude ($5 gratis):")
    print("   Edita .env y agrega ANTHROPIC_API_KEY")
    print("   https://console.anthropic.com/")

print()
