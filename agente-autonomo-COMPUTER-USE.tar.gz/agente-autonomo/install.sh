#!/bin/bash

# Script de instalación para Agente Autónomo
# Ubuntu 22.04+

set -e  # Salir si hay errores

echo "╔═══════════════════════════════════════════════════════╗"
echo "║                                                       ║"
echo "║      🤖  INSTALADOR - AGENTE AUTÓNOMO  🤖            ║"
echo "║                                                       ║"
echo "╚═══════════════════════════════════════════════════════╝"
echo ""

# Colores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # Sin color

# Verificar que estamos en Ubuntu
if ! grep -q "Ubuntu" /etc/os-release; then
    echo -e "${RED}⚠️  Advertencia: Este script está diseñado para Ubuntu${NC}"
    read -p "¿Continuar de todas formas? (s/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[SsYy]$ ]]; then
        exit 1
    fi
fi

echo -e "${BLUE}📦 Paso 1: Actualizando sistema...${NC}"
sudo apt update
sudo apt upgrade -y

echo ""
echo -e "${BLUE}📦 Paso 2: Instalando dependencias del sistema...${NC}"
sudo apt install -y \
    python3 \
    python3-pip \
    python3-venv \
    git \
    curl \
    wget \
    xdotool \
    xvfb \
    scrot \
    chromium-browser \
    firefox

echo ""
echo -e "${BLUE}📦 Paso 3: Instalando Node.js (opcional)...${NC}"
if ! command -v node &> /dev/null; then
    echo "Node.js no encontrado, instalando..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
else
    echo "Node.js ya está instalado: $(node --version)"
fi

echo ""
echo -e "${BLUE}🐍 Paso 4: Configurando entorno virtual de Python...${NC}"
cd "$(dirname "$0")"
python3 -m venv venv

echo ""
echo -e "${BLUE}📚 Paso 5: Instalando dependencias de Python...${NC}"
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

echo ""
echo -e "${BLUE}🎭 Paso 6: Instalando navegadores para Playwright...${NC}"
playwright install chromium
playwright install-deps

echo ""
echo -e "${BLUE}⚙️  Paso 7: Configurando archivo .env...${NC}"
if [ ! -f .env ]; then
    cp .env.example .env
    echo -e "${YELLOW}✏️  Archivo .env creado desde .env.example${NC}"
    echo ""
    echo -e "${BLUE}═══════════════════════════════════════════${NC}"
    echo -e "${BLUE}  IMPORTANTE: Elige tu proveedor de IA   ${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════${NC}"
    echo ""
    echo "1. 🆓 Ollama - 100% GRATIS (local)"
    echo "2. 💳 Claude - De pago ($5 gratis al registrarte)"
    echo "3. 🔀 Ambos - Ollama como fallback"
    echo ""
    read -p "Selecciona (1/2/3): " -n 1 -r
    echo ""
    
    if [[ $REPLY =~ ^[1]$ ]]; then
        echo -e "${BLUE}Instalando Ollama...${NC}"
        if ! command -v ollama &> /dev/null; then
            curl -fsSL https://ollama.ai/install.sh | sh
        fi
        
        echo ""
        echo "¿Qué modelo descargar?"
        echo "1. llama3.1 (8GB RAM) - Recomendado"
        echo "2. llama3.2:3b (4GB RAM) - Para PCs con poca RAM"
        echo "3. mistral (8GB RAM) - Alternativa rápida"
        read -p "Selecciona (1/2/3): " -n 1 -r
        echo ""
        
        case $REPLY in
            1) ollama pull llama3.1 ;;
            2) ollama pull llama3.2:3b ;;
            3) ollama pull mistral ;;
        esac
        
        echo -e "${GREEN}✓ Ollama configurado${NC}"
        echo ""
        echo "Iniciando servidor Ollama..."
        nohup ollama serve > /dev/null 2>&1 &
        echo -e "${GREEN}✓ Servidor Ollama iniciado${NC}"
        
    elif [[ $REPLY =~ ^[2]$ ]]; then
        echo ""
        echo -e "${YELLOW}🔑 Necesitas configurar tu API key de Anthropic${NC}"
        echo "1. Ve a: https://console.anthropic.com/"
        echo "2. Crea una cuenta (obtienes $5 gratis)"
        echo "3. Genera una API key"
        echo "4. Edita .env y agrégala: nano .env"
        
    elif [[ $REPLY =~ ^[3]$ ]]; then
        echo -e "${BLUE}Instalando Ollama como fallback...${NC}"
        if ! command -v ollama &> /dev/null; then
            curl -fsSL https://ollama.ai/install.sh | sh
        fi
        ollama pull llama3.1
        nohup ollama serve > /dev/null 2>&1 &
        
        echo ""
        echo -e "${YELLOW}🔑 También configura tu API key de Claude${NC}"
        echo "Edita .env y agrega ANTHROPIC_API_KEY"
        echo "El agente usará Claude mientras tengas crédito,"
        echo "y cambiará automáticamente a Ollama cuando se acabe."
    fi
else
    echo -e "${GREEN}✓ Archivo .env ya existe${NC}"
fi

echo ""
echo -e "${BLUE}📁 Paso 8: Creando directorios necesarios...${NC}"
mkdir -p data logs

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                       ║${NC}"
echo -e "${GREEN}║           ✅  INSTALACIÓN COMPLETADA  ✅              ║${NC}"
echo -e "${GREEN}║                                                       ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""

echo -e "${YELLOW}📝 Próximos pasos:${NC}"
echo ""
echo "1. Configura tus API keys en el archivo .env:"
echo -e "   ${BLUE}nano .env${NC}"
echo ""
echo "2. Activa el entorno virtual:"
echo -e "   ${BLUE}source venv/bin/activate${NC}"
echo ""
echo "3. Ejecuta el agente en modo CLI:"
echo -e "   ${BLUE}python main.py cli${NC}"
echo ""
echo "   O en modo Telegram:"
echo -e "   ${BLUE}python main.py telegram${NC}"
echo ""
echo "4. Para verificar la instalación:"
echo -e "   ${BLUE}python main.py test${NC}"
echo ""
echo -e "${YELLOW}📚 Recursos:${NC}"
echo "  • Obtén tu API key de Anthropic: https://console.anthropic.com/"
echo "  • Crea un bot de Telegram: https://t.me/BotFather"
echo ""
echo -e "${GREEN}¡Disfruta de tu agente autónomo!${NC} 🤖"
