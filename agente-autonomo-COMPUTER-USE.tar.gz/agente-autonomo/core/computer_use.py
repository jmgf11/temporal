"""
Computer Use - Control completo del desktop
Permite al agente ver la pantalla, mover el mouse, hacer clicks y escribir
"""

import os
import json
import base64
import logging
from typing import Dict, Any, Optional, Tuple
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)


class ComputerController:
    """Controlador para interactuar con el desktop"""
    
    def __init__(self):
        self.screen_width = 1920
        self.screen_height = 1080
        
        # Inicializar PyAutoGUI
        try:
            import pyautogui
            pyautogui.FAILSAFE = True  # Mover mouse a esquina superior izquierda para abortar
            self.pyautogui = pyautogui
            
            # Obtener dimensiones reales de pantalla
            size = pyautogui.size()
            self.screen_width = size.width
            self.screen_height = size.height
            
            logger.info(f"ComputerController inicializado: {self.screen_width}x{self.screen_height}")
        except ImportError:
            logger.error("pyautogui no está instalado")
            self.pyautogui = None
    
    def screenshot(self, save_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Toma un screenshot de la pantalla completa
        Retorna la imagen en base64 para que el LLM pueda verla
        """
        if not self.pyautogui:
            return {"error": "pyautogui no disponible"}
        
        try:
            # Tomar screenshot
            screenshot = self.pyautogui.screenshot()
            
            # Guardar si se especifica path
            if save_path:
                screenshot.save(save_path)
            else:
                # Guardar con timestamp
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                save_path = f"/tmp/screenshot_{timestamp}.png"
                screenshot.save(save_path)
            
            # Convertir a base64 para el LLM
            from io import BytesIO
            buffered = BytesIO()
            screenshot.save(buffered, format="PNG")
            img_base64 = base64.b64encode(buffered.getvalue()).decode()
            
            return {
                "success": True,
                "path": save_path,
                "width": self.screen_width,
                "height": self.screen_height,
                "image_base64": img_base64[:1000] + "...",  # Truncar para logs
                "message": f"Screenshot capturado: {save_path}"
            }
            
        except Exception as e:
            logger.error(f"Error tomando screenshot: {e}")
            return {"error": str(e)}
    
    def mouse_move(self, x: int, y: int, duration: float = 0.5) -> Dict[str, Any]:
        """Mueve el mouse a coordenadas específicas"""
        if not self.pyautogui:
            return {"error": "pyautogui no disponible"}
        
        try:
            # Validar coordenadas
            x = max(0, min(x, self.screen_width))
            y = max(0, min(y, self.screen_height))
            
            # Mover mouse
            self.pyautogui.moveTo(x, y, duration=duration)
            
            return {
                "success": True,
                "x": x,
                "y": y,
                "message": f"Mouse movido a ({x}, {y})"
            }
            
        except Exception as e:
            logger.error(f"Error moviendo mouse: {e}")
            return {"error": str(e)}
    
    def mouse_click(
        self, 
        x: Optional[int] = None, 
        y: Optional[int] = None,
        button: str = "left",
        clicks: int = 1
    ) -> Dict[str, Any]:
        """
        Hace click en una posición
        Si no se especifica x,y usa la posición actual
        """
        if not self.pyautogui:
            return {"error": "pyautogui no disponible"}
        
        try:
            # Si se especifican coordenadas, mover primero
            if x is not None and y is not None:
                x = max(0, min(x, self.screen_width))
                y = max(0, min(y, self.screen_height))
                self.pyautogui.moveTo(x, y, duration=0.3)
            
            # Hacer click
            self.pyautogui.click(button=button, clicks=clicks)
            
            pos = self.pyautogui.position()
            
            return {
                "success": True,
                "x": pos.x,
                "y": pos.y,
                "button": button,
                "clicks": clicks,
                "message": f"Click {button} en ({pos.x}, {pos.y})"
            }
            
        except Exception as e:
            logger.error(f"Error haciendo click: {e}")
            return {"error": str(e)}
    
    def keyboard_type(self, text: str, interval: float = 0.05) -> Dict[str, Any]:
        """Escribe texto usando el teclado"""
        if not self.pyautogui:
            return {"error": "pyautogui no disponible"}
        
        try:
            # Escribir texto
            self.pyautogui.write(text, interval=interval)
            
            return {
                "success": True,
                "text": text,
                "length": len(text),
                "message": f"Texto escrito: '{text[:50]}...'" if len(text) > 50 else f"Texto escrito: '{text}'"
            }
            
        except Exception as e:
            logger.error(f"Error escribiendo texto: {e}")
            return {"error": str(e)}
    
    def keyboard_press(self, key: str) -> Dict[str, Any]:
        """
        Presiona una tecla específica
        Ejemplos: 'enter', 'tab', 'esc', 'ctrl', 'alt', etc.
        """
        if not self.pyautogui:
            return {"error": "pyautogui no disponible"}
        
        try:
            # Presionar tecla
            self.pyautogui.press(key)
            
            return {
                "success": True,
                "key": key,
                "message": f"Tecla presionada: {key}"
            }
            
        except Exception as e:
            logger.error(f"Error presionando tecla: {e}")
            return {"error": str(e)}
    
    def keyboard_hotkey(self, *keys) -> Dict[str, Any]:
        """
        Presiona combinación de teclas
        Ejemplo: keyboard_hotkey('ctrl', 'c') para copiar
        """
        if not self.pyautogui:
            return {"error": "pyautogui no disponible"}
        
        try:
            # Presionar combinación
            self.pyautogui.hotkey(*keys)
            
            return {
                "success": True,
                "keys": list(keys),
                "message": f"Hotkey presionado: {'+'.join(keys)}"
            }
            
        except Exception as e:
            logger.error(f"Error con hotkey: {e}")
            return {"error": str(e)}
    
    def find_on_screen(self, image_path: str, confidence: float = 0.8) -> Dict[str, Any]:
        """
        Busca una imagen en la pantalla
        Útil para encontrar botones, iconos, etc.
        """
        if not self.pyautogui:
            return {"error": "pyautogui no disponible"}
        
        try:
            # Buscar imagen
            location = self.pyautogui.locateOnScreen(image_path, confidence=confidence)
            
            if location:
                center = self.pyautogui.center(location)
                return {
                    "success": True,
                    "found": True,
                    "x": center.x,
                    "y": center.y,
                    "width": location.width,
                    "height": location.height,
                    "message": f"Imagen encontrada en ({center.x}, {center.y})"
                }
            else:
                return {
                    "success": True,
                    "found": False,
                    "message": "Imagen no encontrada en pantalla"
                }
            
        except Exception as e:
            logger.error(f"Error buscando en pantalla: {e}")
            return {"error": str(e)}
    
    def scroll(self, clicks: int, direction: str = "down") -> Dict[str, Any]:
        """
        Hace scroll con el mouse
        clicks: cantidad de scroll (positivo = abajo, negativo = arriba)
        """
        if not self.pyautogui:
            return {"error": "pyautogui no disponible"}
        
        try:
            # Ajustar dirección
            if direction == "up":
                clicks = abs(clicks)
            elif direction == "down":
                clicks = -abs(clicks)
            
            # Hacer scroll
            self.pyautogui.scroll(clicks)
            
            return {
                "success": True,
                "clicks": clicks,
                "direction": direction,
                "message": f"Scroll {direction}: {abs(clicks)} clicks"
            }
            
        except Exception as e:
            logger.error(f"Error haciendo scroll: {e}")
            return {"error": str(e)}
    
    def get_mouse_position(self) -> Dict[str, Any]:
        """Obtiene la posición actual del mouse"""
        if not self.pyautogui:
            return {"error": "pyautogui no disponible"}
        
        try:
            pos = self.pyautogui.position()
            
            return {
                "success": True,
                "x": pos.x,
                "y": pos.y,
                "message": f"Posición del mouse: ({pos.x}, {pos.y})"
            }
            
        except Exception as e:
            logger.error(f"Error obteniendo posición: {e}")
            return {"error": str(e)}
    
    def drag(self, x: int, y: int, duration: float = 0.5) -> Dict[str, Any]:
        """Arrastra desde la posición actual hasta x,y"""
        if not self.pyautogui:
            return {"error": "pyautogui no disponible"}
        
        try:
            start_pos = self.pyautogui.position()
            
            # Validar coordenadas destino
            x = max(0, min(x, self.screen_width))
            y = max(0, min(y, self.screen_height))
            
            # Arrastrar
            self.pyautogui.dragTo(x, y, duration=duration)
            
            return {
                "success": True,
                "start_x": start_pos.x,
                "start_y": start_pos.y,
                "end_x": x,
                "end_y": y,
                "message": f"Arrastrado desde ({start_pos.x}, {start_pos.y}) hasta ({x}, {y})"
            }
            
        except Exception as e:
            logger.error(f"Error arrastrando: {e}")
            return {"error": str(e)}


# Instancia global
_computer_controller = None

def get_computer_controller() -> ComputerController:
    """Obtiene la instancia del controlador (singleton)"""
    global _computer_controller
    if _computer_controller is None:
        _computer_controller = ComputerController()
    return _computer_controller
