"""
Agente Autónomo - Core
Maneja la lógica principal del agente y la ejecución de herramientas
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
from core.llm_providers import LLMManager
from core.computer_use import get_computer_controller

logger = logging.getLogger(__name__)


class AutonomousAgent:
    """Agente autónomo con capacidades de ejecución de herramientas"""
    
    def __init__(
        self, 
        name: str = "Agente",
        model: str = None,
        max_iterations: int = 10
    ):
        self.name = name
        self.model = model or os.getenv("DEFAULT_MODEL", "claude-sonnet-4-20250514")
        self.max_iterations = max_iterations
        
        # Inicializar gestor de LLM con fallback automático
        try:
            self.llm_manager = LLMManager()
            logger.info(f"LLM Manager inicializado")
            logger.info(f"Proveedores disponibles: {', '.join(self.llm_manager.list_providers())}")
            logger.info(f"Proveedor activo: {self.llm_manager.get_current_provider_name()}")
        except Exception as e:
            logger.error(f"Error inicializando LLM Manager: {e}")
            raise ValueError(
                "No se pudo inicializar ningún proveedor de LLM. "
                "Opciones:\n"
                "1. Configura ANTHROPIC_API_KEY en .env\n"
                "2. Configura OPENAI_API_KEY en .env\n"
                "3. Instala Ollama: curl -fsSL https://ollama.ai/install.sh | sh"
            )
        
        self.conversation_history: List[Dict] = []
        self.tools = self._load_tools()
        self.computer = get_computer_controller()
        
        logger.info(f"Agente '{name}' inicializado")
    
    def _load_tools(self) -> List[Dict]:
        """Define las herramientas disponibles para el agente"""
        return [
            {
                "name": "bash",
                "description": """Ejecuta comandos bash en el sistema Ubuntu.
                Puedes usar esto para:
                - Listar archivos y directorios
                - Crear, mover o eliminar archivos
                - Instalar paquetes (con sudo si es necesario)
                - Ejecutar scripts
                - Verificar procesos del sistema
                
                Ejemplos:
                - ls -la /home
                - cat archivo.txt
                - python3 script.py
                - sudo apt install paquete
                """,
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "command": {
                            "type": "string",
                            "description": "Comando bash a ejecutar"
                        }
                    },
                    "required": ["command"]
                }
            },
            {
                "name": "browser",
                "description": """Navega en internet usando un navegador headless.
                Acciones disponibles:
                - navigate: Ir a una URL y obtener el contenido
                - screenshot: Tomar captura de pantalla
                - extract: Extraer información específica
                
                Útil para:
                - Buscar información en línea
                - Extraer datos de páginas web
                - Verificar estados de servicios
                - Descargar contenido
                """,
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "url": {
                            "type": "string",
                            "description": "URL a visitar"
                        },
                        "action": {
                            "type": "string",
                            "enum": ["navigate", "screenshot", "extract"],
                            "description": "Acción a realizar"
                        },
                        "selector": {
                            "type": "string",
                            "description": "Selector CSS (opcional, para extract)"
                        }
                    },
                    "required": ["url", "action"]
                }
            },
            {
                "name": "file_operation",
                "description": """Realiza operaciones con archivos y directorios.
                Operaciones disponibles:
                - read: Leer contenido de un archivo
                - write: Escribir contenido en un archivo
                - list: Listar archivos en un directorio
                - search: Buscar archivos por nombre o patrón
                
                Ejemplos:
                - Leer: {"operation": "read", "path": "/home/user/file.txt"}
                - Escribir: {"operation": "write", "path": "output.txt", "content": "..."}
                - Listar: {"operation": "list", "path": "/home/user"}
                """,
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "operation": {
                            "type": "string",
                            "enum": ["read", "write", "list", "search"],
                            "description": "Operación a realizar"
                        },
                        "path": {
                            "type": "string",
                            "description": "Ruta del archivo o directorio"
                        },
                        "content": {
                            "type": "string",
                            "description": "Contenido para write"
                        },
                        "pattern": {
                            "type": "string",
                            "description": "Patrón de búsqueda para search"
                        }
                    },
                    "required": ["operation", "path"]
                }
            },
            {
                "name": "python_execute",
                "description": """Ejecuta código Python de forma segura.
                Útil para:
                - Análisis de datos
                - Cálculos complejos
                - Procesamiento de texto
                - Generación de gráficos
                
                El código se ejecuta en un entorno aislado.
                """,
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "code": {
                            "type": "string",
                            "description": "Código Python a ejecutar"
                        }
                    },
                    "required": ["code"]
                }
            },
            {
                "name": "computer_screenshot",
                "description": """Toma un screenshot de la pantalla del desktop.
                Esto permite ver exactamente lo que hay en pantalla.
                Útil para:
                - Ver qué aplicaciones están abiertas
                - Verificar estados de ventanas
                - Leer contenido visual
                - Navegar interfaces gráficas
                """,
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "save_path": {
                            "type": "string",
                            "description": "Ruta donde guardar el screenshot (opcional)"
                        }
                    }
                }
            },
            {
                "name": "computer_mouse",
                "description": """Controla el mouse del desktop.
                Acciones disponibles:
                - move: Mover mouse a coordenadas X,Y
                - click: Hacer click (left/right/middle)
                - drag: Arrastrar desde posición actual a nueva posición
                - position: Obtener posición actual del mouse
                - scroll: Hacer scroll arriba/abajo
                
                Coordenadas en píxeles desde esquina superior izquierda.
                """,
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": ["move", "click", "drag", "position", "scroll"],
                            "description": "Acción a realizar con el mouse"
                        },
                        "x": {
                            "type": "integer",
                            "description": "Coordenada X (para move, click, drag)"
                        },
                        "y": {
                            "type": "integer",
                            "description": "Coordenada Y (para move, click, drag)"
                        },
                        "button": {
                            "type": "string",
                            "enum": ["left", "right", "middle"],
                            "description": "Botón del mouse (para click)"
                        },
                        "clicks": {
                            "type": "integer",
                            "description": "Número de clicks (para click)"
                        },
                        "scroll_amount": {
                            "type": "integer",
                            "description": "Cantidad de scroll (para scroll)"
                        },
                        "direction": {
                            "type": "string",
                            "enum": ["up", "down"],
                            "description": "Dirección del scroll"
                        }
                    },
                    "required": ["action"]
                }
            },
            {
                "name": "computer_keyboard",
                "description": """Controla el teclado del desktop.
                Acciones disponibles:
                - type: Escribir texto
                - press: Presionar una tecla específica (enter, tab, esc, etc.)
                - hotkey: Presionar combinación de teclas (ctrl+c, alt+tab, etc.)
                
                Ejemplos:
                - Escribir texto: {"action": "type", "text": "Hola mundo"}
                - Presionar Enter: {"action": "press", "key": "enter"}
                - Copiar: {"action": "hotkey", "keys": ["ctrl", "c"]}
                - Pegar: {"action": "hotkey", "keys": ["ctrl", "v"]}
                """,
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": ["type", "press", "hotkey"],
                            "description": "Acción a realizar con el teclado"
                        },
                        "text": {
                            "type": "string",
                            "description": "Texto a escribir (para type)"
                        },
                        "key": {
                            "type": "string",
                            "description": "Tecla a presionar (para press)"
                        },
                        "keys": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Lista de teclas para combinación (para hotkey)"
                        }
                    },
                    "required": ["action"]
                }
            }
        ]
    
    def process_tool_call(self, tool_name: str, tool_input: Dict[str, Any]) -> Dict[str, Any]:
        """Ejecuta la herramienta solicitada y retorna el resultado"""
        logger.info(f"Ejecutando herramienta: {tool_name}")
        logger.debug(f"Input: {tool_input}")
        
        try:
            if tool_name == "bash":
                result = self._execute_bash(tool_input["command"])
            elif tool_name == "browser":
                result = self._browser_action(tool_input)
            elif tool_name == "file_operation":
                result = self._file_operation(tool_input)
            elif tool_name == "python_execute":
                result = self._python_execute(tool_input["code"])
            elif tool_name == "computer_screenshot":
                result = self.computer.screenshot(tool_input.get("save_path"))
            elif tool_name == "computer_mouse":
                result = self._computer_mouse_action(tool_input)
            elif tool_name == "computer_keyboard":
                result = self._computer_keyboard_action(tool_input)
            else:
                result = {"error": f"Herramienta '{tool_name}' no encontrada"}
            
            logger.debug(f"Resultado: {result}")
            return result
            
        except Exception as e:
            error_msg = f"Error ejecutando {tool_name}: {str(e)}"
            logger.error(error_msg)
            return {"error": error_msg}
    
    def _execute_bash(self, command: str) -> Dict[str, Any]:
        """Ejecuta un comando bash con seguridad"""
        import subprocess
        
        # Verificar si bash está permitido
        if not os.getenv("ALLOW_BASH", "false").lower() == "true":
            return {"error": "Ejecución de bash deshabilitada"}
        
        # Lista de comandos prohibidos
        forbidden = ['rm -rf /', 'mkfs', 'dd if=/dev/zero', 'fork bomb', ':()', 'chmod -R 777 /']
        
        if any(forbidden_cmd in command.lower() for forbidden_cmd in forbidden):
            return {"error": "Comando potencialmente peligroso bloqueado"}
        
        # Limitar longitud
        max_length = int(os.getenv("MAX_COMMAND_LENGTH", "500"))
        if len(command) > max_length:
            return {"error": f"Comando demasiado largo (máx {max_length} caracteres)"}
        
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30,
                cwd=os.path.expanduser("~")
            )
            
            return {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
                "success": result.returncode == 0
            }
        except subprocess.TimeoutExpired:
            return {"error": "Comando excedió el tiempo límite (30s)"}
        except Exception as e:
            return {"error": str(e)}
    
    def _browser_action(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Navega en el navegador usando Playwright"""
        from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout
        
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                page = browser.new_page()
                
                # Navegar a la URL
                page.goto(params["url"], timeout=15000)
                page.wait_for_load_state("networkidle", timeout=10000)
                
                action = params["action"]
                
                if action == "screenshot":
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    screenshot_path = f"/tmp/screenshot_{timestamp}.png"
                    page.screenshot(path=screenshot_path)
                    browser.close()
                    return {
                        "success": True,
                        "screenshot_path": screenshot_path,
                        "url": params["url"]
                    }
                
                elif action == "extract":
                    selector = params.get("selector")
                    if selector:
                        elements = page.query_selector_all(selector)
                        content = [el.text_content() for el in elements]
                    else:
                        content = page.content()[:5000]  # Limitar contenido
                    
                    browser.close()
                    return {
                        "success": True,
                        "content": content,
                        "url": params["url"]
                    }
                
                else:  # navigate
                    title = page.title()
                    content = page.content()[:3000]  # Primeros 3000 caracteres
                    
                    browser.close()
                    return {
                        "success": True,
                        "title": title,
                        "content": content,
                        "url": params["url"]
                    }
                    
        except PlaywrightTimeout:
            return {"error": "Timeout navegando a la página"}
        except Exception as e:
            return {"error": f"Error en navegador: {str(e)}"}
    
    def _file_operation(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Operaciones con archivos del sistema"""
        import glob
        
        operation = params["operation"]
        path = os.path.expanduser(params["path"])
        
        try:
            if operation == "read":
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
                return {
                    "success": True,
                    "content": content,
                    "path": path,
                    "size": len(content)
                }
            
            elif operation == "write":
                content = params.get("content", "")
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(content)
                return {
                    "success": True,
                    "path": path,
                    "bytes_written": len(content)
                }
            
            elif operation == "list":
                if os.path.isfile(path):
                    return {"error": "La ruta es un archivo, no un directorio"}
                
                items = []
                for item in os.listdir(path):
                    item_path = os.path.join(path, item)
                    items.append({
                        "name": item,
                        "type": "dir" if os.path.isdir(item_path) else "file",
                        "size": os.path.getsize(item_path) if os.path.isfile(item_path) else None
                    })
                
                return {
                    "success": True,
                    "path": path,
                    "items": items,
                    "count": len(items)
                }
            
            elif operation == "search":
                pattern = params.get("pattern", "*")
                search_path = os.path.join(path, pattern)
                matches = glob.glob(search_path, recursive=True)
                
                return {
                    "success": True,
                    "matches": matches[:100],  # Limitar a 100 resultados
                    "count": len(matches)
                }
            
        except FileNotFoundError:
            return {"error": f"Archivo o directorio no encontrado: {path}"}
        except PermissionError:
            return {"error": f"Permiso denegado: {path}"}
        except Exception as e:
            return {"error": str(e)}
    
    def _python_execute(self, code: str) -> Dict[str, Any]:
        """Ejecuta código Python en un entorno controlado"""
        import sys
        from io import StringIO
        
        # Capturar stdout
        old_stdout = sys.stdout
        sys.stdout = captured_output = StringIO()
        
        try:
            # Ejecutar código
            exec(code, {"__builtins__": __builtins__})
            
            # Obtener output
            output = captured_output.getvalue()
            
            return {
                "success": True,
                "output": output
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "error_type": type(e).__name__
            }
        finally:
            sys.stdout = old_stdout
    
    def _computer_mouse_action(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Ejecuta acciones del mouse"""
        action = params.get("action")
        
        if action == "move":
            x = params.get("x", 0)
            y = params.get("y", 0)
            return self.computer.mouse_move(x, y)
        
        elif action == "click":
            x = params.get("x")
            y = params.get("y")
            button = params.get("button", "left")
            clicks = params.get("clicks", 1)
            return self.computer.mouse_click(x, y, button, clicks)
        
        elif action == "drag":
            x = params.get("x", 0)
            y = params.get("y", 0)
            return self.computer.drag(x, y)
        
        elif action == "position":
            return self.computer.get_mouse_position()
        
        elif action == "scroll":
            amount = params.get("scroll_amount", 3)
            direction = params.get("direction", "down")
            return self.computer.scroll(amount, direction)
        
        else:
            return {"error": f"Acción de mouse '{action}' no reconocida"}
    
    def _computer_keyboard_action(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Ejecuta acciones del teclado"""
        action = params.get("action")
        
        if action == "type":
            text = params.get("text", "")
            return self.computer.keyboard_type(text)
        
        elif action == "press":
            key = params.get("key", "")
            return self.computer.keyboard_press(key)
        
        elif action == "hotkey":
            keys = params.get("keys", [])
            if keys:
                return self.computer.keyboard_hotkey(*keys)
            else:
                return {"error": "No se especificaron teclas para hotkey"}
        
        else:
            return {"error": f"Acción de teclado '{action}' no reconocida"}
    
    def run(self, user_message: str) -> str:
        """
        Ejecuta el agente con un mensaje del usuario
        Maneja múltiples iteraciones de tool use
        """
        logger.info(f"Recibido mensaje: {user_message}")
        
        # Agregar mensaje del usuario
        self.conversation_history.append({
            "role": "user",
            "content": user_message
        })
        
        iteration = 0
        
        while iteration < self.max_iterations:
            iteration += 1
            logger.debug(f"Iteración {iteration}/{self.max_iterations}")
            
            # Llamar al LLM usando el manager (con fallback automático)
            response = self.llm_manager.generate(
                messages=self.conversation_history,
                tools=self.tools,
                max_tokens=int(os.getenv("MAX_TOKENS", "4096"))
            )
            
            # Extraer respuesta del formato unificado
            stop_reason = response.get("stop_reason", "end_turn")
            content = response.get("content", [])
            
            # Si no hay tool use, terminamos
            if stop_reason != "tool_use":
                # Extraer respuesta final
                final_response = ""
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        final_response += block.get("text", "")
                    elif hasattr(block, "text"):
                        final_response += block.text
                
                self.conversation_history.append({
                    "role": "assistant",
                    "content": content
                })
                
                logger.info(f"Respuesta final generada por {self.llm_manager.get_current_provider_name()}")
                return final_response
            
            # Procesar tool calls
            tool_results = []
            assistant_content = []
            
            for block in content:
                block_dict = block if isinstance(block, dict) else {
                    "type": getattr(block, "type", "text"),
                    "id": getattr(block, "id", None),
                    "name": getattr(block, "name", None),
                    "input": getattr(block, "input", None),
                    "text": getattr(block, "text", None)
                }
                
                if block_dict.get("type") == "tool_use":
                    logger.info(f"Tool call: {block_dict.get('name')}")
                    result = self.process_tool_call(
                        block_dict.get("name"),
                        block_dict.get("input", {})
                    )
                    
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block_dict.get("id"),
                        "content": json.dumps(result, ensure_ascii=False)
                    })
                    
                    assistant_content.append(block_dict)
                elif block_dict.get("text"):
                    assistant_content.append(block_dict)
            
            # Agregar a la historia
            self.conversation_history.append({
                "role": "assistant",
                "content": assistant_content
            })
            
            self.conversation_history.append({
                "role": "user",
                "content": tool_results
            })
        
        # Si llegamos aquí, excedimos las iteraciones
        logger.warning(f"Máximo de iteraciones ({self.max_iterations}) alcanzado")
        return f"⚠️ Se alcanzó el límite de {self.max_iterations} iteraciones. La tarea puede no estar completa."
    
    def reset_conversation(self):
        """Reinicia la conversación"""
        self.conversation_history = []
        logger.info("Conversación reiniciada")
    
    def get_conversation_length(self) -> int:
        """Retorna el número de mensajes en la conversación"""
        return len(self.conversation_history)
