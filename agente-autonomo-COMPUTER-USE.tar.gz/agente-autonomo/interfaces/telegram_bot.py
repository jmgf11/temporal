"""
Bot de Telegram para el Agente Autónomo
"""

import os
import sys
import logging
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
    ContextTypes
)
from core.agent import AutonomousAgent

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('data/telegram_bot.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# Diccionario para mantener agentes por usuario
user_agents = {}


def get_agent_for_user(user_id: int) -> AutonomousAgent:
    """Obtiene o crea un agente para un usuario específico"""
    if user_id not in user_agents:
        agent_name = f"Agente_{user_id}"
        user_agents[user_id] = AutonomousAgent(name=agent_name)
        logger.info(f"Nuevo agente creado para usuario {user_id}")
    
    return user_agents[user_id]


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /start"""
    user = update.effective_user
    
    welcome_message = f"""
🤖 ¡Hola {user.first_name}! 

Soy tu Agente Autónomo personal. Puedo ayudarte con:

✅ Ejecutar comandos bash
✅ Navegar por internet
✅ Manipular archivos
✅ Ejecutar código Python
✅ Y mucho más...

📚 Comandos disponibles:
/start - Mensaje de bienvenida
/help - Ayuda detallada
/reset - Reiniciar conversación
/status - Ver estado del agente

💡 Simplemente envíame un mensaje con lo que necesitas!
    """
    
    # Teclado inline con opciones rápidas
    keyboard = [
        [
            InlineKeyboardButton("📚 Ayuda", callback_data='help'),
            InlineKeyboardButton("ℹ️ Estado", callback_data='status')
        ],
        [
            InlineKeyboardButton("🔄 Reset", callback_data='reset'),
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        welcome_message,
        reply_markup=reply_markup
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /help"""
    help_text = """
📚 **Guía de Uso**

**Comandos Básicos:**
/start - Iniciar el bot
/help - Ver esta ayuda
/reset - Reiniciar la conversación
/status - Ver estado actual

**Ejemplos de Uso:**

📂 **Archivos:**
• "Lista los archivos en /home"
• "Crea un archivo test.txt con contenido 'Hola'"
• "Lee el contenido del archivo config.json"

💻 **Bash:**
• "Ejecuta el comando 'df -h'"
• "Muéstrame los procesos en ejecución"
• "Instala el paquete curl"

🌐 **Navegador:**
• "Busca información sobre Python en internet"
• "Toma un screenshot de google.com"
• "Extrae los títulos de https://news.ycombinator.com"

🐍 **Python:**
• "Ejecuta un script que calcule los primeros 10 números primos"
• "Calcula la media de estos números: 5, 10, 15, 20"

**Tips:**
• Sé específico en tus solicitudes
• Puedo recordar el contexto de la conversación
• Si algo no funciona, intenta reformular tu pregunta
    """
    
    await update.message.reply_text(help_text, parse_mode='Markdown')


async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /status"""
    user_id = update.effective_user.id
    agent = get_agent_for_user(user_id)
    
    msg_count = agent.get_conversation_length()
    
    status_text = f"""
📊 **Estado del Agente**

🤖 Nombre: {agent.name}
🧠 Modelo: {agent.model}
💬 Mensajes: {msg_count}
🔧 Herramientas: {len(agent.tools)}
⚙️ Max iteraciones: {agent.max_iterations}

📝 Herramientas disponibles:
• bash - Comandos del sistema
• browser - Navegación web
• file_operation - Archivos
• python_execute - Código Python
    """
    
    await update.message.reply_text(status_text, parse_mode='Markdown')


async def reset_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /reset"""
    user_id = update.effective_user.id
    agent = get_agent_for_user(user_id)
    agent.reset_conversation()
    
    await update.message.reply_text(
        "🔄 Conversación reiniciada. Empecemos de nuevo!"
    )


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Maneja los mensajes de texto del usuario"""
    user_id = update.effective_user.id
    user_message = update.message.text
    
    logger.info(f"Mensaje de usuario {user_id}: {user_message}")
    
    # Obtener agente del usuario
    agent = get_agent_for_user(user_id)
    
    # Mostrar indicador de "escribiendo..."
    await update.message.chat.send_action("typing")
    
    try:
        # Procesar mensaje
        start_time = datetime.now()
        response = agent.run(user_message)
        end_time = datetime.now()
        
        duration = (end_time - start_time).total_seconds()
        
        # Agregar tiempo de procesamiento
        footer = f"\n\n⏱️ Tiempo: {duration:.2f}s"
        
        # Telegram tiene límite de 4096 caracteres
        if len(response) + len(footer) > 4090:
            # Dividir en múltiples mensajes
            chunks = [response[i:i+4000] for i in range(0, len(response), 4000)]
            
            for i, chunk in enumerate(chunks):
                if i == len(chunks) - 1:
                    await update.message.reply_text(chunk + footer)
                else:
                    await update.message.reply_text(chunk)
        else:
            await update.message.reply_text(response + footer)
        
        logger.info(f"Respuesta enviada a usuario {user_id}")
        
    except Exception as e:
        error_message = f"❌ Error procesando tu mensaje: {str(e)}"
        await update.message.reply_text(error_message)
        logger.error(f"Error procesando mensaje de {user_id}: {e}", exc_info=True)


async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Maneja callbacks de botones inline"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    data = query.data
    
    if data == 'help':
        await help_command(query, context)
    elif data == 'status':
        await status_command(query, context)
    elif data == 'reset':
        agent = get_agent_for_user(user_id)
        agent.reset_conversation()
        await query.message.reply_text("🔄 Conversación reiniciada!")


async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Maneja errores globales"""
    logger.error(f"Error: {context.error}", exc_info=context.error)
    
    if update and update.message:
        await update.message.reply_text(
            "❌ Ocurrió un error interno. Por favor intenta de nuevo."
        )


def main():
    """Función principal del bot"""
    
    # Verificar token
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        print("❌ Error: TELEGRAM_BOT_TOKEN no está configurado")
        print("Por favor, configura tu .env con el token de tu bot de Telegram")
        sys.exit(1)
    
    # Verificar API key de Anthropic
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("❌ Error: ANTHROPIC_API_KEY no está configurada")
        print("Por favor, configura tu .env con tu clave de API de Anthropic")
        sys.exit(1)
    
    print("🤖 Iniciando bot de Telegram...")
    
    # Crear aplicación
    application = Application.builder().token(token).build()
    
    # Agregar handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("status", status_command))
    application.add_handler(CommandHandler("reset", reset_command))
    application.add_handler(CallbackQueryHandler(button_callback))
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        handle_message
    ))
    
    # Agregar error handler
    application.add_error_handler(error_handler)
    
    # Iniciar bot
    print("✅ Bot iniciado correctamente")
    print("📱 Esperando mensajes...")
    print("Presiona Ctrl+C para detener\n")
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
