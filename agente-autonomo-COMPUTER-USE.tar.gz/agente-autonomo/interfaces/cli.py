"""
Interfaz CLI para el Agente Autónomo
"""

import os
import sys
import logging
from datetime import datetime
from core.agent import AutonomousAgent

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('data/agent.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


def print_banner():
    """Muestra el banner del agente"""
    banner = """
╔═══════════════════════════════════════════════════════╗
║                                                       ║
║          🤖  AGENTE AUTÓNOMO  🤖                      ║
║                                                       ║
║  Tu asistente de IA con capacidades de:              ║
║    • Ejecutar comandos bash                          ║
║    • Navegar en la web                               ║
║    • Manipular archivos                              ║
║    • Ejecutar código Python                          ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝
    """
    print(banner)


def print_help():
    """Muestra los comandos disponibles"""
    help_text = """
📚 Comandos Especiales:
  /help     - Muestra esta ayuda
  /reset    - Reinicia la conversación
  /status   - Muestra el estado del agente
  /clear    - Limpia la pantalla
  /exit     - Sale del programa
  
💡 Ejemplos de uso:
  • "Lista los archivos en el directorio actual"
  • "Busca información sobre Python en internet"
  • "Crea un archivo llamado test.txt con contenido 'Hola mundo'"
  • "Ejecuta el comando 'df -h' para ver el espacio en disco"
  • "Toma un screenshot de google.com"
    """
    print(help_text)


def clear_screen():
    """Limpia la pantalla"""
    os.system('clear' if os.name != 'nt' else 'cls')


def main():
    """Función principal del CLI"""
    
    # Verificar variables de entorno
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("❌ Error: ANTHROPIC_API_KEY no está configurada")
        print("Por favor, configura tu .env con tu clave de API de Anthropic")
        sys.exit(1)
    
    clear_screen()
    print_banner()
    
    # Inicializar agente
    agent_name = os.getenv("AGENT_NAME", "MiAgente")
    
    try:
        agent = AutonomousAgent(name=agent_name)
        print(f"✅ Agente '{agent_name}' inicializado correctamente")
        print(f"📊 Modelo: {agent.model}")
        print(f"🔧 Herramientas disponibles: {len(agent.tools)}")
        print("\nEscribe /help para ver los comandos disponibles\n")
    except Exception as e:
        print(f"❌ Error inicializando el agente: {e}")
        logger.error(f"Error de inicialización: {e}", exc_info=True)
        sys.exit(1)
    
    # Loop principal
    while True:
        try:
            # Obtener input del usuario
            user_input = input(f"\n💬 Tú: ").strip()
            
            # Verificar comandos especiales
            if not user_input:
                continue
            
            if user_input.startswith('/'):
                command = user_input.lower()
                
                if command in ['/exit', '/quit', '/salir']:
                    print("\n👋 ¡Hasta luego!")
                    break
                
                elif command == '/help':
                    print_help()
                    continue
                
                elif command == '/reset':
                    agent.reset_conversation()
                    print("🔄 Conversación reiniciada")
                    continue
                
                elif command == '/status':
                    msg_count = agent.get_conversation_length()
                    print(f"\n📊 Estado del Agente:")
                    print(f"  • Nombre: {agent.name}")
                    print(f"  • Modelo: {agent.model}")
                    print(f"  • Mensajes en conversación: {msg_count}")
                    print(f"  • Herramientas: {len(agent.tools)}")
                    continue
                
                elif command == '/clear':
                    clear_screen()
                    print_banner()
                    continue
                
                else:
                    print(f"❌ Comando desconocido: {command}")
                    print("Escribe /help para ver los comandos disponibles")
                    continue
            
            # Procesar mensaje
            print(f"\n🤖 {agent.name}: 🤔 Procesando...\n")
            
            start_time = datetime.now()
            response = agent.run(user_input)
            end_time = datetime.now()
            
            duration = (end_time - start_time).total_seconds()
            
            # Mostrar respuesta
            print(f"🤖 {agent.name}: {response}")
            print(f"\n⏱️  Tiempo: {duration:.2f}s")
            
        except KeyboardInterrupt:
            print("\n\n⚠️  Interrupción detectada")
            confirm = input("¿Seguro que quieres salir? (s/n): ").lower()
            if confirm in ['s', 'si', 'y', 'yes']:
                print("👋 ¡Hasta luego!")
                break
            else:
                continue
        
        except Exception as e:
            print(f"\n❌ Error: {e}")
            logger.error(f"Error en el loop principal: {e}", exc_info=True)
            
            # Preguntar si continuar
            continue_choice = input("\n¿Continuar? (s/n): ").lower()
            if continue_choice not in ['s', 'si', 'y', 'yes']:
                break


if __name__ == "__main__":
    main()
