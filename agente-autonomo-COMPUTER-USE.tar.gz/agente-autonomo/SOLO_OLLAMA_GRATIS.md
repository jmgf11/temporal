# 🆓 GUÍA SIMPLIFICADA: Agente 100% GRATIS (Solo Ollama)

## ✨ Sin API Keys, Sin Pagos, Sin Límites

Esta guía te muestra cómo instalar el agente usando **SOLO Ollama** - completamente gratis.

**No necesitas:**
- ❌ API keys de ningún tipo
- ❌ Tarjeta de crédito
- ❌ Registrarte en ningún servicio
- ❌ Pagar nada nunca

**Solo necesitas:**
- ✅ VM Ubuntu con 8GB+ RAM
- ✅ 20GB espacio libre
- ✅ 15 minutos de tiempo

---

## 🚀 INSTALACIÓN EN 7 PASOS

### PASO 1: Preparar VM Ubuntu

**Requisitos:**
- Ubuntu 22.04 o superior
- 8GB RAM (16GB ideal)
- 20GB espacio libre

```bash
# Conectarte a tu VM
# Si es local: ábrela directamente
# Si es remota: ssh usuario@ip-vm

# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Verificar espacio
df -h
# Debe mostrar al menos 20GB libres
```

---

### PASO 2: Transferir el Proyecto

**Desde tu computadora a la VM:**

```bash
# Opción A: SCP (si tienes SSH)
scp agente-autonomo-FINAL.tar.gz usuario@IP_VM:~/

# Opción B: Descargar directo en la VM
# (si lo subes a algún lugar primero)
wget URL_DEL_ARCHIVO
```

**En la VM:**

```bash
# Verificar que llegó
ls -lh ~/agente-autonomo-FINAL.tar.gz
```

---

### PASO 3: Descomprimir

```bash
# Ir a home
cd ~

# Descomprimir
tar -xzf agente-autonomo-FINAL.tar.gz

# Entrar al directorio
cd agente-autonomo

# Verificar contenido
ls
# Deberías ver: install.sh, main.py, requirements.txt, etc.
```

---

### PASO 4: Instalación Automática

```bash
# Hacer ejecutable el instalador
chmod +x install.sh

# Ejecutar
./install.sh
```

**Cuando te pregunte qué proveedor:**

```
═══════════════════════════════════════════
  IMPORTANTE: Elige tu proveedor de IA   
═══════════════════════════════════════════

1. 🆓 Ollama - 100% GRATIS (local)
2. 💳 Claude - De pago ($5 gratis al registrarte)
3. 🔀 Ambos - Ollama como fallback

Selecciona (1/2/3): 
```

**✅ ESCRIBE: 1** y presiona Enter

**Luego te pregunta qué modelo:**

```
¿Qué modelo descargar?
1. llama3.1 (8GB RAM) - Recomendado
2. llama3.2:3b (4GB RAM) - Para PCs con poca RAM
3. mistral (8GB RAM) - Alternativa rápida

Selecciona (1/2/3):
```

**✅ ESCRIBE: 1** (o 2 si solo tienes 4GB RAM)

**Ahora espera 10-15 minutos** mientras descarga el modelo (4-5GB)

---

### PASO 5: Configurar .env (Muy Simple)

```bash
# El instalador ya creó el .env, solo verificar
cat .env
```

Deberías ver algo como:

```env
# Ollama (GRATIS)
OLLAMA_MODEL=llama3.1
OLLAMA_BASE_URL=http://localhost:11434

# Otras configuraciones
AGENT_NAME=MiAgente
ALLOW_BASH=true
```

**No necesitas editar nada más.** ✅

---

### PASO 6: Verificar que Todo Funciona

```bash
# Activar entorno virtual
source venv/bin/activate

# Tu prompt cambiará a:
(venv) usuario@ubuntu:~/agente-autonomo$

# Verificar proveedores
python check_providers.py
```

**Deberías ver:**

```
╔═══════════════════════════════════════════════════════╗
║     🔍  VERIFICADOR DE PROVEEDORES DE IA  🔍         ║
╚═══════════════════════════════════════════════════════╝

1️⃣  Anthropic (Claude)
   ❌ No configurada

2️⃣  OpenAI (GPT)
   ❌ No configurada

3️⃣  Ollama (Local - GRATIS)
   ✅ Disponible y corriendo
   🌐 URL: http://localhost:11434
   🎯 Modelo: llama3.1
   📚 Modelos instalados: 1
   📋 Modelos:
      • llama3.1:latest (4.7GB)

═══════════════════════════════════════════════════════
✅ Proveedores disponibles: Ollama (GRATIS)

🚀 Puedes iniciar el agente con:
   python main.py cli
```

**Si ves esto → ¡TODO LISTO!** 🎉

---

### PASO 7: ¡Usar el Agente!

```bash
# Iniciar en modo CLI
python main.py cli
```

**Verás:**

```
╔═══════════════════════════════════════════════════════╗
║                                                       ║
║          🤖  AGENTE AUTÓNOMO  🤖                      ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝

✅ Agente 'MiAgente' inicializado correctamente
📊 Modelo: llama3.1
🔧 Herramientas disponibles: 4
💰 Proveedor activo: Ollama (llama3.1) - GRATIS

💬 Tú: 
```

**¡YA ESTÁ! Empieza a usarlo.**

---

## 🎮 PRUEBAS RÁPIDAS

Copia y pega estos comandos uno por uno:

```
1. Hola, preséntate

2. ¿Qué puedes hacer?

3. Lista los archivos en mi directorio actual

4. Ejecuta el comando 'uname -a' y dime qué sistema operativo tengo

5. Crea un archivo llamado test.txt con el contenido "Hola desde Ollama gratis"

6. Lee el archivo test.txt

7. Dime cuánta RAM y espacio en disco tengo disponible

8. Busca información sobre Linux en internet
```

---

## 💡 Ejemplos de Uso Real

### Gestión del Sistema

```
💬 Tú: ¿Cuánta RAM estoy usando?

🤖 Agente: [ejecuta free -h]
         
Estás usando 3.2GB de 8GB de RAM disponible (40%).
Tienes 4.8GB libres.

⏱️  Tiempo: 4.2s
💰 GRATIS - Ollama
```

### Trabajar con Archivos

```
💬 Tú: Encuentra todos los archivos .log y dime cuál es el más grande

🤖 Agente: [ejecuta comandos find y ls]

Encontré 12 archivos .log. El más grande es:
/var/log/syslog - 48MB

⏱️  Tiempo: 5.8s
💰 GRATIS - Ollama
```

### Programación

```
💬 Tú: Crea un script Python que imprima los primeros 10 números de Fibonacci

🤖 Agente: [crea archivo fibonacci.py]

Script creado en fibonacci.py con el siguiente código:
[muestra código]

¿Quieres que lo ejecute?

⏱️  Tiempo: 6.5s
💰 GRATIS - Ollama
```

### Navegación Web

```
💬 Tú: Busca información sobre Python en Wikipedia

🤖 Agente: [abre navegador, navega, extrae info]

Python es un lenguaje de programación de alto nivel...
[resumen de información]

⏱️  Tiempo: 12.3s
💰 GRATIS - Ollama
```

---

## 📊 Rendimiento de Ollama

**Velocidad:**
- Tareas simples: 2-5 segundos
- Tareas complejas: 5-15 segundos
- Navegación web: 10-20 segundos

**Calidad:**
- Comandos bash: 9/10
- Gestión archivos: 9/10
- Respuestas conversacionales: 7/10
- Tareas complejas: 7/10

**Comparado con Claude:**
- Claude es ~2-3x más rápido
- Claude es ~20% más preciso
- Pero Ollama es **100% gratis** 🎉

---

## ⚙️ COMANDOS ÚTILES

### Verificar que Ollama Funciona

```bash
# Ver si el servidor está corriendo
ps aux | grep ollama

# Probar conexión
curl localhost:11434/api/tags

# Listar modelos instalados
ollama list
```

### Reiniciar Ollama (si es necesario)

```bash
# Detener
pkill ollama

# Iniciar de nuevo
ollama serve &

# Verificar
curl localhost:11434/api/tags
```

### Cambiar de Modelo

```bash
# Descargar otro modelo
ollama pull mistral

# Editar configuración
nano .env
# Cambiar: OLLAMA_MODEL=mistral

# Reiniciar agente
python main.py cli
```

### Ver Logs

```bash
# Logs del agente
tail -f data/agent.log

# Ver últimas 50 líneas
tail -n 50 data/agent.log
```

---

## 🔧 OPTIMIZACIÓN

### Si va Lento

**1. Usa un modelo más pequeño:**

```bash
ollama pull llama3.2:3b
nano .env
# Cambiar: OLLAMA_MODEL=llama3.2:3b
```

**2. Cierra programas innecesarios:**

```bash
# Ver qué consume RAM
htop
# Cerrar programas pesados
```

**3. Aumenta RAM de la VM:**

- Apaga la VM
- En VirtualBox/VMware: Configuración → Aumentar RAM a 12-16GB
- Reinicia la VM

### Si Tienes GPU NVIDIA

**Ollama usará la GPU automáticamente (10x más rápido):**

```bash
# Verificar GPU
nvidia-smi

# Ollama la detectará solo
ollama run llama3.1

# Durante uso, verificar:
nvidia-smi
# Deberías ver ollama usando la GPU
```

---

## 🐛 SOLUCIÓN DE PROBLEMAS

### "Connection refused" al verificar

```bash
# Iniciar servidor Ollama
ollama serve &

# Verificar
curl localhost:11434/api/tags
```

### Modelo va muy lento (más de 30s por respuesta)

```bash
# Opción 1: Modelo más pequeño
ollama pull llama3.2:3b
nano .env
# Cambiar a: OLLAMA_MODEL=llama3.2:3b

# Opción 2: Aumentar RAM de VM a 16GB

# Opción 3: Cerrar otros programas
```

### "Out of memory"

```bash
# Tu VM no tiene suficiente RAM
# Opción 1: Aumentar RAM de la VM a 12-16GB
# Opción 2: Usar modelo pequeño
ollama pull llama3.2:3b
```

### Agente no responde

```bash
# Ver logs
tail -f data/agent.log

# Ver si Ollama está corriendo
ps aux | grep ollama

# Reiniciar todo
pkill ollama
ollama serve &
python main.py cli
```

---

## 💬 TELEGRAM (OPCIONAL)

Si quieres controlarlo desde tu celular:

**1. Crear bot en Telegram:**
- Buscar @BotFather
- Enviar `/newbot`
- Seguir instrucciones
- Copiar token

**2. Configurar:**

```bash
nano .env
# Agregar línea:
TELEGRAM_BOT_TOKEN=tu_token_aqui
```

**3. Iniciar:**

```bash
python main.py telegram
```

**4. En Telegram:**
- Buscar tu bot
- Enviar `/start`
- ¡Usar desde cualquier lugar!

---

## 📱 MANTENER CORRIENDO 24/7

### Usando Screen

```bash
# Instalar screen
sudo apt install screen

# Crear sesión
screen -S agente

# Dentro, iniciar agente
cd ~/agente-autonomo
source venv/bin/activate
python main.py telegram

# Desconectar (agente sigue corriendo)
Ctrl+A, luego D

# Cerrar SSH - agente sigue funcionando

# Reconectar después
screen -r agente
```

---

## ✅ CHECKLIST FINAL

Antes de empezar a usar:

- [ ] VM con 8GB+ RAM
- [ ] Ollama instalado: `ollama list` muestra llama3.1
- [ ] Servidor corriendo: `curl localhost:11434/api/tags` funciona
- [ ] Entorno activado: `source venv/bin/activate`
- [ ] Verificación OK: `python check_providers.py` muestra ✅
- [ ] Agente inicia: `python main.py cli` funciona

**Si todo ✅ → ¡LISTO PARA USAR!**

---

## 🎯 RESUMEN

**¿Qué tienes?**
- Agente autónomo 100% funcional
- Usa IA de forma completamente gratis
- Sin límites, sin costos, sin API keys
- Controla tu VM, navega web, gestiona archivos

**¿Qué NO necesitas?**
- Tarjeta de crédito
- Registros en servicios
- API keys
- Pagar absolutamente nada

**¿Limitaciones vs Claude?**
- Un poco más lento (2-3x)
- Un poco menos preciso (~20%)
- Pero GRATIS para siempre 🎉

---

## 🚀 ¡A USAR!

```bash
# Cada vez que quieras usar:
cd ~/agente-autonomo
source venv/bin/activate
python main.py cli

# ¡Y listo!
```

---

## 💪 VENTAJAS DE OLLAMA

✅ **$0 total** - Nunca pagas
✅ **Sin límites** - Usa 24/7 sin restricciones
✅ **Privado** - Todo local, tus datos no salen
✅ **Offline** - Funciona sin internet (excepto web search)
✅ **Sin cuentas** - No te registras en nada
✅ **Sin APIs** - No dependes de servicios externos

**Es tu agente, en tu máquina, bajo tu control. Gratis.** 🔥

---

## 🎁 BONUS: Alias Rápido

```bash
# Agregar a ~/.bashrc
echo 'alias agente="cd ~/agente-autonomo && source venv/bin/activate && python main.py cli"' >> ~/.bashrc
source ~/.bashrc

# Ahora desde cualquier lugar solo escribe:
agente
# ¡Y listo!
```

---

## 📚 Más Info

- **OLLAMA_GUIDE.md** - Guía completa de Ollama
- **CHEATSHEET.md** - Comandos rápidos
- **README.md** - Documentación general

---

**¿Dudas? Todo está en los archivos .md incluidos.**

**¡Disfruta de tu agente 100% GRATIS!** 🤖✨
