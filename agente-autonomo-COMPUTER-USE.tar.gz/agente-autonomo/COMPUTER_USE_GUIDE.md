# 🖥️ COMPUTER USE - Control Total del Desktop

## 🎯 ¿Qué es Computer Use?

Tu agente ahora puede **ver y controlar** el desktop como un humano:

✅ **Ver la pantalla** - Toma screenshots y analiza lo que hay
✅ **Mover el mouse** - Controla el cursor pixel por pixel
✅ **Hacer clicks** - Click izquierdo, derecho, doble click
✅ **Escribir** - Usa el teclado para escribir texto
✅ **Presionar teclas** - Enter, Tab, Ctrl+C, Alt+Tab, etc.
✅ **Arrastrar** - Drag and drop
✅ **Scroll** - Desplazar ventanas

**Es como tener a alguien sentado frente a tu computadora haciendo lo que le pidas.**

---

## 🚀 Configuración Inicial

### Paso 1: Instalar Dependencias (si no lo hiciste)

```bash
# Ubuntu/Debian
sudo apt install -y \
    python3-tk \
    python3-dev \
    scrot \
    xdotool \
    xclip

# Instalar PyAutoGUI
pip install pyautogui pillow
```

### Paso 2: Configurar Display (para VMs sin GUI)

Si tu VM no tiene entorno gráfico:

```bash
# Instalar entorno gráfico ligero
sudo apt install -y xfce4 xfce4-goodies

# O instalar solo lo mínimo
sudo apt install -y xorg openbox

# Iniciar servidor X virtual
Xvfb :99 -screen 0 1920x1080x24 &
export DISPLAY=:99
```

### Paso 3: Verificar que Funciona

```bash
cd ~/agente-autonomo
source venv/bin/activate
python -c "import pyautogui; print(pyautogui.size())"
# Debe mostrar: Size(width=1920, height=1080) o similar
```

---

## 💡 Ejemplos de Uso

### Ejemplo 1: Ver la Pantalla

```
💬 Tú: Toma un screenshot y dime qué ves

🤖 Agente: [llama herramienta computer_screenshot]
         [captura pantalla]
         [analiza la imagen]

Veo que tienes:
- Terminal abierto en la parte superior izquierda
- Navegador Firefox en el centro
- Sistema de archivos en la esquina inferior derecha

⏱️  4.5s
```

### Ejemplo 2: Abrir una Aplicación

```
💬 Tú: Abre Firefox

🤖 Agente: [presiona tecla super (Windows)]
         [escribe "firefox"]
         [presiona enter]

Firefox ha sido abierto.

⏱️  3.2s
```

### Ejemplo 3: Navegar en una App

```
💬 Tú: Abre el gestor de archivos y ve a la carpeta Documentos

🤖 Agente: [abre gestor de archivos]
         [hace click en "Documentos"]
         [toma screenshot para verificar]

Estoy en la carpeta Documentos. Veo 15 archivos.

⏱️  6.8s
```

### Ejemplo 4: Copiar y Pegar

```
💬 Tú: Copia el texto de este archivo y pégalo en el navegador

🤖 Agente: [abre archivo]
         [selecciona todo: Ctrl+A]
         [copia: Ctrl+C]
         [cambia a navegador: Alt+Tab]
         [pega: Ctrl+V]

Texto copiado y pegado exitosamente.

⏱️  5.1s
```

### Ejemplo 5: Llenar un Formulario

```
💬 Tú: Llena el formulario en la página web con estos datos:
      Nombre: Juan
      Email: juan@example.com

🤖 Agente: [toma screenshot]
         [identifica campos del formulario]
         [hace click en campo nombre]
         [escribe "Juan"]
         [hace click en campo email]
         [escribe "juan@example.com"]
         [toma screenshot final]

Formulario completado.

⏱️  8.3s
```

---

## 🎮 Comandos Disponibles

### Screenshot
```
"Toma un screenshot"
"Muéstrame qué hay en pantalla"
"Captura la pantalla"
```

### Mouse
```
"Mueve el mouse a las coordenadas 500, 300"
"Haz click en el centro de la pantalla"
"Haz doble click en X, Y"
"Haz click derecho"
"Arrastra desde 100,100 hasta 500,500"
```

### Teclado
```
"Escribe 'Hola mundo'"
"Presiona Enter"
"Presiona Ctrl+C"
"Presiona Alt+Tab"
"Abre el menú de inicio" (presiona tecla Super)
```

### Combinaciones
```
"Abre Firefox, ve a google.com y busca 'Python'"
"Toma un screenshot, guárdalo y muéstramelo"
"Abre el terminal y ejecuta 'ls'"
```

---

## 🎯 Casos de Uso Reales

### 1. Automatizar Tareas Repetitivas

```
💬 Tú: Cada 5 minutos, toma un screenshot y verifica si apareció 
       una notificación. Si aparece, toma nota.

🤖 Agente: [bucle cada 5 min]
         [screenshot]
         [analiza]
         [guarda en log si detecta notificación]
```

### 2. Llenar Formularios

```
💬 Tú: Llena todos los formularios de este sitio con los datos del 
       archivo data.csv

🤖 Agente: [lee CSV]
         [identifica formularios]
         [llena campos]
         [envía]
```

### 3. Probar Interfaces

```
💬 Tú: Prueba esta aplicación web. Haz click en todos los botones y 
       dime si hay errores.

🤖 Agente: [explora interfaz]
         [hace click en botones]
         [verifica respuestas]
         [reporta errores]
```

### 4. Monitorear Aplicaciones

```
💬 Tú: Monitorea esta aplicación y avísame si muestra un error

🤖 Agente: [toma screenshots periódicos]
         [analiza en busca de mensajes de error]
         [alerta si encuentra algo]
```

### 5. Grabar Tutoriales

```
💬 Tú: Quiero hacer un tutorial. Ve tomando screenshots mientras te digo 
       qué hacer, y al final genera un documento con los pasos.

🤖 Agente: [captura cada paso]
         [guarda screenshots]
         [genera documento con imágenes]
```

---

## ⚙️ Coordenadas de Pantalla

El sistema de coordenadas:

```
(0,0) ←─────────────────────→ (1920,0)
  ↓                              ↓
  │     Tu Pantalla              │
  │        1920x1080             │
  ↓                              ↓
(0,1080) ←───────────────────→ (1920,1080)
```

**Puntos comunes:**
- Centro: (960, 540)
- Esquina superior izquierda: (0, 0)
- Esquina superior derecha: (1920, 0)
- Esquina inferior izquierda: (0, 1080)
- Esquina inferior derecha: (1920, 1080)

---

## 🔧 Tips y Trucos

### 1. Siempre Toma Screenshot Primero

```
💬 Tú: Haz click en el botón "Guardar"

❌ MAL: El agente no sabe dónde está el botón

✅ BIEN: "Toma un screenshot, encuentra el botón Guardar, y haz click"
```

### 2. Usa Coordenadas Relativas

```
"Haz click en el centro de la pantalla"  ← Mejor
"Haz click en 960,540"  ← También funciona pero menos flexible
```

### 3. Verifica Después de Cada Acción

```
💬 Tú: Abre Firefox y verifica que se abrió

🤖 Agente: [abre Firefox]
         [toma screenshot]
         [confirma que Firefox está abierto]
```

### 4. Usa Delays para Apps Lentas

```
💬 Tú: Abre esta aplicación pesada, espera 5 segundos, y luego haz click

🤖 Agente: [abre app]
         [espera]
         [verifica que cargó]
         [hace click]
```

---

## ⚠️ Limitaciones

### Lo que SÍ puede hacer:
✅ Ver la pantalla actual
✅ Controlar mouse y teclado
✅ Interactuar con cualquier app visible
✅ Automatizar tareas repetitivas
✅ Llenar formularios
✅ Navegar interfaces

### Lo que NO puede hacer:
❌ Ver apps minimizadas (solo ve lo que está en pantalla)
❌ Detectar cambios si no toma screenshots frecuentes
❌ Interactuar con apps que requieren permisos especiales
❌ Trabajar si la pantalla está apagada
❌ OCR perfecto en textos muy pequeños

---

## 🐛 Solución de Problemas

### "pyautogui not found"

```bash
pip install pyautogui pillow
```

### "DISPLAY not set"

```bash
# Para VM sin GUI
export DISPLAY=:99
Xvfb :99 -screen 0 1920x1080x24 &
```

### Screenshots en Negro

```bash
# Instalar scrot
sudo apt install scrot

# O usar gnome-screenshot
sudo apt install gnome-screenshot
```

### Mouse se Mueve Muy Rápido/Lento

```python
# En .env, agregar:
MOUSE_DURATION=0.5  # Segundos para mover mouse
```

### No Puede Hacer Click en Ciertos Elementos

```
# Tomar screenshot primero para ver dónde están las cosas
# Luego indicar coordenadas exactas
```

---

## 🎓 Ejemplos Avanzados

### Auto-guardar Screenshots Cada Minuto

```
💬 Tú: Toma un screenshot cada minuto y guárdalos numerados en /tmp/monitors/

🤖 Agente: [bucle infinito]
         [cada 60s: screenshot]
         [guarda como monitor_001.png, monitor_002.png, etc.]
```

### Encontrar y Click en Imagen

```
💬 Tú: Busca el botón con el logo de Chrome y haz click

🤖 Agente: [toma screenshot]
         [analiza visualmente]
         [identifica logo de Chrome]
         [calcula coordenadas]
         [hace click]
```

### Macro Complejo

```
💬 Tú: Abre LibreOffice, crea un documento, escribe "Hola Mundo",
       ponlo en negrita, guárdalo como test.odt

🤖 Agente: [abre LibreOffice Writer]
         [espera a que cargue]
         [escribe texto]
         [selecciona texto: Ctrl+A]
         [pone en negrita: Ctrl+B]
         [guarda: Ctrl+S]
         [escribe nombre: test.odt]
         [presiona Enter]

Documento creado y guardado exitosamente.
```

---

## 📊 Rendimiento

| Acción | Tiempo Promedio |
|--------|-----------------|
| Screenshot | 0.5-1s |
| Mover mouse | 0.3-0.5s |
| Click | 0.1s |
| Escribir (por carácter) | 0.05s |
| Análisis visual | 2-5s |

**Nota:** Ollama será un poco más lento en analizar screenshots (5-10s)

---

## ✅ Checklist para Empezar

- [ ] Dependencias instaladas (scrot, xdotool)
- [ ] PyAutoGUI funcionando: `python -c "import pyautogui"`
- [ ] Display configurado (si es VM sin GUI)
- [ ] Screenshot funciona: `pyautogui.screenshot()`
- [ ] Agente actualizado con computer use

---

## 🎉 ¡Ahora Tienes Control Total!

Tu agente puede:
- 👀 Ver tu pantalla
- 🖱️ Controlar el mouse
- ⌨️ Usar el teclado  
- 🤖 Automatizar cualquier cosa

**Es como tener un asistente sentado frente a tu computadora 24/7.**

---

**Ejemplos para probar ahora:**

```
"Toma un screenshot y dime qué aplicaciones tengo abiertas"
"Abre el terminal"
"Escribe 'echo Hola desde el agente' y presiona Enter"
"Toma otro screenshot para confirmar que funcionó"
```

**¡Diviértete automatizando!** 🚀
