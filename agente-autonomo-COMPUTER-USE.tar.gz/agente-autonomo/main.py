#!/usr/bin/env python3
"""
Punto de Entrada del Agente Autónomo
Soporta múltiples modos de ejecución
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Agregar directorio raíz al path
root_dir = Path(__file__).parent
sys.path.insert(0, str(root_dir))

# Cargar variables de entorno
env_path = root_dir / '.env'
if env_path.exists():
    load_dotenv(env_path)
    print(f"✅ Variables de entorno cargadas desde {env_path}")
else:
    print(f"⚠️  Archivo .env no encontrado en {env_path}")
    print("Copia .env.example a .env y configura tus API keys")

# Crear directorio de datos si no existe
data_dir = root_dir / 'data'
data_dir.mkdir(exist_ok=True)


def print_usage():
    """Muestra información de uso"""
    usage = """
╔═══════════════════════════════════════════════════════╗
║          🤖  AGENTE AUTÓNOMO  🤖                      ║
╚═══════════════════════════════════════════════════════╝

Uso: python main.py [modo]

Modos disponibles:
  cli       - Interfaz de línea de comandos (interactiva)
  telegram  - Bot de Telegram
  test      - Ejecutar tests básicos
  
Ejemplos:
  python main.py cli
  python main.py telegram
  
Variables de entorno requeridas:
  ANTHROPIC_API_KEY    - Clave de API de Anthropic (requerida)
  TELEGRAM_BOT_TOKEN   - Token del bot de Telegram (solo para modo telegram)
  
Para más información: https://github.com/tu-repo
    """
    print(usage)


def check_requirements():
    """Verifica que las dependencias estén instaladas"""
    missing = []
    
    try:
        import anthropic
    except ImportError:
        missing.append("anthropic")
    
    try:
        import dotenv
    except ImportError:
        missing.append("python-dotenv")
    
    if missing:
        print(f"❌ Faltan dependencias: {', '.join(missing)}")
        print("\nInstala con:")
        print(f"  pip install {' '.join(missing)}")
        return False
    
    return True


def test_mode():
    """Modo de prueba - verifica la configuración"""
    print("\n🧪 Modo de Prueba\n")
    
    # Verificar API key
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if api_key:
        masked = api_key[:8] + "..." + api_key[-4:]
        print(f"✅ ANTHROPIC_API_KEY configurada: {masked}")
    else:
        print("❌ ANTHROPIC_API_KEY no configurada")
        return
    
    # Verificar importaciones
    print("\n📦 Verificando dependencias...")
    try:
        from core.agent import AutonomousAgent
        print("✅ core.agent importado correctamente")
        
        # Crear agente de prueba
        print("\n🤖 Creando agente de prueba...")
        agent = AutonomousAgent(name="TestAgent")
        print(f"✅ Agente creado: {agent.name}")
        print(f"   Modelo: {agent.model}")
        print(f"   Herramientas: {len(agent.tools)}")
        
        # Prueba simple
        print("\n💬 Ejecutando prueba simple...")
        response = agent.run("Di 'Hola, funciono correctamente!'")
        print(f"🤖 Respuesta: {response}")
        
        print("\n✅ Todas las pruebas pasaron correctamente!")
        
    except Exception as e:
        print(f"❌ Error en las pruebas: {e}")
        import traceback
        traceback.print_exc()


def cli_mode():
    """Modo CLI interactivo"""
    print("🚀 Iniciando modo CLI...\n")
    
    try:
        from interfaces.cli import main as cli_main
        cli_main()
    except KeyboardInterrupt:
        print("\n\n👋 Programa interrumpido por el usuario")
    except Exception as e:
        print(f"❌ Error en modo CLI: {e}")
        import traceback
        traceback.print_exc()


def telegram_mode():
    """Modo bot de Telegram"""
    print("🚀 Iniciando bot de Telegram...\n")
    
    # Verificar token
    if not os.getenv("TELEGRAM_BOT_TOKEN"):
        print("❌ Error: TELEGRAM_BOT_TOKEN no está configurado")
        print("Configura tu token en el archivo .env")
        sys.exit(1)
    
    try:
        from interfaces.telegram_bot import main as telegram_main
        telegram_main()
    except KeyboardInterrupt:
        print("\n\n👋 Bot detenido por el usuario")
    except Exception as e:
        print(f"❌ Error en bot de Telegram: {e}")
        import traceback
        traceback.print_exc()


def main():
    """Función principal"""
    
    # Verificar argumentos
    if len(sys.argv) < 2:
        print_usage()
        sys.exit(0)
    
    # Verificar dependencias
    if not check_requirements():
        sys.exit(1)
    
    mode = sys.argv[1].lower()
    
    # Verificar API key para modos que lo necesitan
    if mode in ['cli', 'telegram', 'test']:
        if not os.getenv("ANTHROPIC_API_KEY"):
            print("❌ Error: ANTHROPIC_API_KEY no está configurada")
            print("Por favor, configura tu .env con tu clave de API de Anthropic")
            print("\n1. Copia .env.example a .env")
            print("2. Edita .env y agrega tu ANTHROPIC_API_KEY")
            print("3. Obtén tu clave en: https://console.anthropic.com/")
            sys.exit(1)
    
    # Ejecutar modo seleccionado
    if mode == "cli":
        cli_mode()
    elif mode == "telegram":
        telegram_mode()
    elif mode == "test":
        test_mode()
    else:
        print(f"❌ Modo '{mode}' no reconocido\n")
        print_usage()
        sys.exit(1)


if __name__ == "__main__":
    main()
